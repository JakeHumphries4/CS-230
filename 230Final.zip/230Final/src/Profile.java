import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * The user playing the game, can play multiple levels which each have instances
 * of player. Only one instance of profile per user.
 *
 * @author Ciara
 * @version 1.4
 */
public class Profile {

    private String userName;
    private int currentLevel;
    private String character;
    public ArrayList<Boolean> continueLevelArray = new ArrayList<Boolean>();

    /**
     * Constructs a profile.
     *
     * @param userName  The user's username to be referred to during the game.
     * @param level     The highest level they have accessed.
     * @param character The character they have chosen tot play as.
     */
    public Profile(String userName, String level, String character) {
        this.userName = userName;
        this.character = character;
        this.currentLevel = Integer.parseInt(level);
        for (int i = 0; i <= 6; i++) {
            continueLevelArray.add(i, false);
        }
    }

    public String getUserName() {
        return userName;
    }

    public String getCharacter() {
        return character;
    }

    /**
     * This method goes though the array and returns if theres a current save
     * file in place
     *
     * @param level the level that wants to be taught
     * @return continueState returns state of level
     */
    public Boolean getContinueLevelArray(int level) {
        Boolean continueState = false;

        for (int i = 0; i < continueLevelArray.size(); i++) {
            if (i == level) {
                continueState = continueLevelArray.get(i);
            }
        }
        return continueState;

    }

    /**
     * This method goes though the array and changes state in array
     *
     * @param level         the level that wants to be taught
     * @param continueState the state that the level will be changed to
     */
    public void setContinueLevelArray(int level, Boolean continueState) {
        for (int i = 0; i < continueLevelArray.size(); i++) {
            if (i == level) {
                continueLevelArray.set(i, continueState);
            }
        }
    }

    public void setCharacter(String character) {
        this.character = character;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getCurrentLevel() {
        return currentLevel;
    }

    public void setCurrentLevel(int currentLevel) {
        this.currentLevel = currentLevel;
    }

    /**
     * getting the instance of level and profile instance and saves it using
     * filereader
     *
     * @param levelInstance
     * @param profileInstance
     */
    public void saveState(Level levelInstance, Profile profileInstance) {
        FileReader.Save(levelInstance, profileInstance);

    }

    /**
     * This is a save method and can be used to save the the profile
     */
    public void save() {
        String rewrite = "";
        String line = "";
        Scanner in = new Scanner("Player.txt");
        do {
            String thisLine = in.nextLine();
            if (!(thisLine.contains(userName))) {
                rewrite.concat(thisLine + "\n");
            }
        } while (in.hasNextLine());
        line = userName + " " + currentLevel + " " + character + "\n";
        try {
            FileWriter writer = new FileWriter("Player.txt", false);
            writer.write(rewrite + line);
            writer.close();
        } catch (IOException ex) {
            System.out.println("Saving Failed");
        }
    }

}