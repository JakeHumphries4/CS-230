/**
 * A navigator is a character in the game that can move around the level - a player or an enemy.
 *
 * @author Tom and Jake
 * @version 1.3
 */

public abstract class Navigator {
    private Cell cell;

    /**
     * Constructor creates a new Navigator with a reference to a Cell that they are standing on in the game.
     *
     * @param cell
     */
    public Navigator(Cell cell) {
        this.cell = cell;
    }

    /**
     * Checks whether navigator can, by the rules of the game, move onto a cell
     *
     * @param moveCell The new cell to move to.
     * @return True or false.
     */
    protected boolean isValidMove(Cell moveCell) {
        return moveCell != null &&
                (moveCell.getCellType().equals("ground"));
    }

    /**
     * Checks whether the navigator can move north.
     *
     * @return True or false.
     */
    protected boolean moveNorth() {
        if (isValidMove(cell.getNorth())) {
            cell = cell.getNorth();
            return true;
        }
        return false;
    }

    /**
     * Checks whether the navigator can move east.
     *
     * @return True or false.
     */
    protected boolean moveEast() {
        if (isValidMove(cell.getEast())) {
            cell = cell.getEast();
            return true;
        }
        return false;
    }

    /**
     * Checks whether the navigator can move south.
     *
     * @return True or false.
     */
    protected boolean moveSouth() {
        if (isValidMove(cell.getSouth())) {
            cell = cell.getSouth();
            return true;
        }
        return false;
    }

    /**
     * Checks whether the navigator can move west.
     *
     * @return True or false.
     */
    protected boolean moveWest() {
        if (isValidMove(cell.getWest())) {
            cell = cell.getWest();
            return true;
        }
        return false;
    }

    /**
     * Gets the navigators x-coordinate.
     *
     * @return The xcoord.
     */
    public int getxCoord() {
        return cell.getxCoord();
    }

    /**
     * Gets the navigators y-coordinate.
     *
     * @return The ycoord.
     */
    public int getyCoord() {
        return cell.getyCoord();
    }

    /**
     * Gets the cell the navigator is standing on.
     *
     * @return The cell the navigator in on.
     */
    public Cell getCell() {
        return cell;
    }

    /**
     * Sets the cell the navigator is standing on.
     *
     * @param cell The cell the navigator is on.
     */
    public void setCell(Cell cell) {
        this.cell = cell;
    }

    /**
     * Returns the navigators position as a string times by 100 to render their corresponding sprite in that position on the screen.
     *
     * @return String position.
     */
    public String toString() {
        return (" Position: [" + this.getxCoord() * 100 + "," + this.getyCoord() * 100 + "]");
    }
}
