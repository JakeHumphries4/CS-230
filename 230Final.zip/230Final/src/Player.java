import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A player instantiated when a level is loaded, is a character within the game.
 *
 * @author Ciara & Ruth
 * @version 1.4
 */

public class Player extends Navigator {

    private ArrayList<String> inventory = new ArrayList<String>();
    private int tokens;
    private Boolean reachedGoal;
    private Boolean dead;
    private long startTime;
    private long stopTime;
    private long timePlayed;
    private Level level;

    /**
     * Constructor instantiates a Player with a reference to a Cell.
     */
    public Player(Cell cell) {
        super(cell);
        tokens = 0;
        timePlayed = 0;
        reachedGoal = false;
        dead = false;
    }

    /**
     * Gets the players inventory of collectables that they have picked up within the current level.
     *
     * @return the player inventory.
     */
    public ArrayList<String> getInventory() {
        return inventory;
    }

    /**
     * Sets the players inventory of collectables.
     *
     * @param inventory The new inventory.
     */
    public void setInventory(ArrayList<String> inventory) {
        this.inventory = inventory;
    }

    /**
     * Adds a collectable to the players inventory.
     *
     * @param collectable The new collectable.
     */
    public void addInventory(String collectable) {
        inventory.add(collectable);
    }

    /**
     * Removes a collectable from the players inventory.
     * Should only be called when the player uses a collectable during the game.
     *
     * @param collectable Colleactable to remove.
     */
    public void removeInventory(String collectable) {
        inventory.remove(collectable);
    }

    /**
     * Returns whether the player has reached the end goal in the level or not.
     *
     * @return reachedGoal
     */
    public Boolean getReachedGoal() {
        return reachedGoal;
    }

    /**
     * Sets reachedGoal to true and updates timePlayed.
     * Should only be called when player has completed level.
     */
    public void setReachedGoal(long stopTime) {
        this.stopTime = stopTime;
        this.reachedGoal = true;
        //TODO check where to put calculate time played in code when level is completed
        calculateTimePlayed();
    }

    /**
     * Returns whether player has been killed or not.
     *
     * @return dead
     */
    public Boolean getDead() {
        return dead;
    }

    /**
     * Sets dead to true.
     * Should only be called when player has been killed (by enemies or a killCell).
     */
    public void die() {
        this.dead = true;
    }

    /**
     * Gets the total number of tokens the player has.
     *
     * @return tokens
     */
    public int getTokens() {
        return tokens;
    }

    /**
     * Sets the total number of tokens the player has.
     *
     * @param tokens
     */
    public void setTokens(int tokens) {
        this.tokens = tokens;
    }

    /**
     * Adds one to the total number of tokens the player has.
     */
    public void addToken() {
        this.tokens += 1;
    }

    public void subTokens(int num) {
        this.tokens -= num;
    }

    /**
     * Gets the time the player started or restarted playing the level.
     *
     * @return The level start time.
     */
    public long getStartTime() {
        return startTime;
    }

    /**
     * Sets the time the player started or restarted playing the level from the System clock.
     */
    public void setStartTime() {
        this.startTime = System.nanoTime();
    }

    /**
     * Gets the time the player has spent playing the level.
     *
     * @return time spent playing level.
     */
    public long getTimePlayed() {
        return timePlayed;
    }

    /**
     * Set the time the player has spent playing the level.
     *
     * @param timePlayed
     */
    public void setTimePlayed(long timePlayed) {
        this.timePlayed = timePlayed;
    }

    /**
     * Calculates the time the player has spent playing the level, adding the timePlayed previously recorded to most recent time taken playing the level.
     */
    public void calculateTimePlayed() {
        timePlayed = timePlayed + (stopTime - startTime) / 1000000000;
        //timeplayed now in seconds
    }

    public String timePlayedToString() {
        long seconds = timePlayed % 60;
        long minutes = Math.floorDiv(timePlayed, 60);
        return (minutes + "." + seconds);
    }

    /**
     * Gets the instance of level the player is playing.
     *
     * @return Level currently being played.
     */
    public Level getLevel() {
        return level;
    }

    /**
     * Sets the level the player is playing.
     *
     * @param level Instance of level.
     */
    public void setLevel(Level level) {
        this.level = level;
    }


    /**
     * Checks whether a given cell can be moved onto by the player.
     *
     * @param moveCell The new cell to move to.
     * @return True or false.
     */
    protected boolean isValidMove(Cell moveCell) {
        ArrayList<String> allowedCells = new ArrayList<String>();
        List<String> allowedCellsList = Arrays.asList("ground", "goal", "bone", "cigs", "1", "2",
                "3", "token", "teleport", "dog", "prisoner");
        if (inventory.contains("1") && !allowedCells.contains("keyDoor1"))
            allowedCells.add("keyDoor1");
        if (inventory.contains("1") && !allowedCells.contains("keyDoor2"))
            allowedCells.add("keyDoor2");
        if (inventory.contains("1") && !allowedCells.contains("keyDoor3"))
            allowedCells.add("keyDoor3");
        if (tokens >= 1 && !allowedCells.contains("tokenDoor1"))
            allowedCells.add("tokenDoor1");
        if (tokens >= 2 && !allowedCells.contains("tokenDoor2"))
            allowedCells.add("tokenDoor2");
        if (tokens >= 3 && !allowedCells.contains("tokenDoor3"))
            allowedCells.add("tokenDoor3");
        if (tokens >= 4 && !allowedCells.contains("tokenDoor4"))
            allowedCells.add("tokenDoor4");
        if (tokens < 1 && allowedCells.contains("tokenDoor1"))
            allowedCells.remove("tokenDoor1");
        if (tokens < 2 && allowedCells.contains("tokenDoor2"))
            allowedCells.remove("tokenDoor2");
        if (tokens < 3 && allowedCells.contains("tokenDoor3"))
            allowedCells.remove("tokenDoor3");
        if (tokens < 4 && allowedCells.contains("tokenDoor4"))
            allowedCells.remove("tokenDoor4");
        allowedCells.addAll(allowedCellsList);
        if (moveCell != null) {
            for (Navigator navigator : level.getNavigators()) {

                if (navigator != this) {

                    if (navigator.getxCoord() == moveCell.getxCoord() && navigator.getyCoord() == moveCell.getyCoord()) {
                        die();

                    }
                }
            }

            return allowedCells.contains(moveCell.getCellType());
        }
        return false;
    }

    /**
     * Checks whether the player can move in a given direction onto another cell, adhering to the rules of the game.
     *
     * @param direction north, east, south, west
     * @return True or false.
     */
    public boolean move(String direction) {
        switch (direction) {
            case "UP":
                if (isValidMove(getCell().getNorth())) {
                    return moveNorth();
                }
                break;
            case "RIGHT":
                if (isValidMove(getCell().getEast())) {
                    return moveEast();
                }
                break;
            case "DOWN":
                if (isValidMove(getCell().getSouth())) {
                    return moveSouth();
                }
                break;
            case "LEFT":
                if (isValidMove(getCell().getWest())) {
                    return moveWest();
                }
                break;
        }
        return false;
    }
}
