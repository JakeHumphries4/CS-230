/**
 * This class represents a teleport cell.
 *
 * @author Jake, Ruth, Johannes
 */
public class Teleport extends Cell {
    Teleport pair;
    private String number;

    /**
     * Creates an instance of the teleport cell
     *
     * @param xCoord x coordinate of the cell
     * @param yCoord y coordinate of the cell
     * @param number a int that represents the number-pair of 2 teleporters
     */
    public Teleport(int xCoord, int yCoord, String number) {
        super(xCoord, yCoord, "teleport");
        this.pair = null;
        this.number = number;
    }

    /**
     * Creates an instance of the teleport cell
     *
     * @param xCoord x coordinate of the cell
     * @param yCoord y coordinate of the cell
     * @param pair   a Teleport cell instance to hold as a reference so we can get its data
     */
    public Teleport(int xCoord, int yCoord, Teleport pair) {
        super(xCoord, yCoord, "teleport");
        this.pair = pair;
    }

    /**
     * Gets the number of the teleporter
     *
     * @return teleporter number
     */
    public String getNumber() {
        return number;
    }

    /**
     * Gets the number of the teleporter
     *
     * @param number teleporter number
     */
    public void setNumber(String number) {
        this.number = number;
    }

    /**
     * Returns the teleporter Instance that the current object is paired with
     *
     * @return Teleporter object, pair
     */
    public Teleport getPair() {
        return pair;
    }

    /**
     * Sets a teleporter object as a reference in pair
     *
     * @param pair Teleporter object
     */
    public void setPair(Teleport pair) {
        this.pair = pair;
    }

}

