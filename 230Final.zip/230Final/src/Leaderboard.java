import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

/**
 * Reads and writes leaderboard files.
 * Decides whether a profiles score should be put on the leaderboard for a given level
 * And if it should be on the leaderboard, then in what place.
 *
 * @author Ruth and Jake
 * @version 1.1
 */
public class Leaderboard {
    String[] usernames;
    String[] times;

    /**
     * Checks and updates leaderboard if needed after a level has been completed.
     *
     * @param filename The name of the relevant leaderboard text file.
     * @param player   The current player.
     * @param profile  The current profile.
     */
    public void updateLeaderboard(String filename, Player player, Profile profile) {
        readLeaderBoard(filename);
        //compareLeaderboard(playerTime);
        rewriteLeaderBoard(filename);
    }

    /**
     * Reads leader board data from file and stores in 2d arrays.
     *
     * @param fileName Relevant file name.
     */
    private void readLeaderBoard(String fileName) {
        try {
            File file = new File(fileName);
            Scanner in = new Scanner(file);
            for (int i = 0; i < 3; i++) {
                usernames[i] = in.nextLine();
                times[i] = in.nextLine();
            }
        } catch (Exception e) {
            System.out.println("file not found");
        }
    }

    /**
     * Converts timePlayed into easily comparable data.
     *
     * @param time Time to convert.
     * @return Time in seconds.
     */
    private int timePlayedToInt(String time) {
        String[] splitTime = time.split(".");
        int minsToSec = Integer.parseInt(splitTime[0]) * 60;
        int seconds = Integer.parseInt(splitTime[1]);

        return minsToSec + seconds;
    }

    /**
     * Converts seconds to minutes and seconds to print.
     *
     * @param time Time in seconds.
     * @return Time in minutes and seconds
     */
    private String timePlayedToString(int time) {
        int seconds = time % 60;
        int minutes = Math.floorDiv(time, 60);
        return (minutes + "." + seconds);
    }

    /**
     * Compares the given players score to those on the leader board.
     * Adds it to the leaderboard if necessary.
     *
     * @param playerTime The given players score.
     */
    private void compareLeaderboard(int playerTime) {
        int third = timePlayedToInt(times[2]);
        int second = timePlayedToInt(times[1]);
        int first = timePlayedToInt(times[0]);
        if (playerTime < third && playerTime >= second) {
            addToLeaderboard(2, playerTime);
        } else if (playerTime < second && playerTime >= first) {
            addToLeaderboard(1, playerTime);
        } else if (playerTime < first) {
            addToLeaderboard(0, playerTime);
        }
    }

    /**
     * Adds the player score to the leaderboard in the appropriate place
     *
     * @param index      Where in the array the players score should be.
     * @param playerTime The given players score.
     */
    private void addToLeaderboard(int index, int playerTime) {
        if (index == 2) {
            times[2] = timePlayedToString(playerTime);
        } else if (index == 1) {
            times[2] = times[1];
            times[1] = timePlayedToString(playerTime);
        } else if (index == 0) {
            times[2] = times[1];
            times[1] = times[0];
            times[0] = timePlayedToString(playerTime);
        }
    }

    /**
     * Writes the updated leaderboard data to the necessary file.
     *
     * @param fileName The relevant file name.
     */
    private void rewriteLeaderBoard(String fileName) {
        try {
            FileWriter out = new FileWriter(fileName, false);
            for (int i = 0; i < 3; i++) {
                out.write(usernames[i] + "\n");
                out.write(times[i] + "\n");
            }
            out.close();
        } catch (Exception e) {
            System.out.println("file not found");
        }
    }
}