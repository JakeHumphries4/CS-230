/**
 * This class is for creating a wall enemy.
 *
 * @author Thomas Williams
 * @version 3.2
 */

public class WallEnemy extends Navigator {

    private String direction; //The current direction the enemy is travelling

    /**
     * Constructor for a wall enemy
     *
     * @param direction The enemies current direction
     */
    public WallEnemy(Cell cell, String direction) {
        super(cell); //Inherits coordinates from Navigator
        this.direction = direction;
    }

    /**
     * This method gets the enemies current direction
     *
     * @return The current direction
     */
    public String getDirection() {
        return direction;
    }

    /**
     * This methods sets the direction of the enemy
     *
     * @param direction The new direction an enemy should travel
     */
    public void setDirection(String direction) {
        this.direction = direction;
    }

    /**
     * This method calculates the next move of the wall enemy,
     * by calling methods from navigator in order to check
     * for walls, allowing the enemy to move
     */
    public String move() {
        /*
         * The method checks the cell to the left of the enemy,
         * and moves if its a ground cell. If its not ground, then it
         * will do the same for the cell in front, and if thats ground,
         * it will check the cell to its right. If that to is ground, then it
         * will move backwards, as it has reached a dead end.
         */
        String shiftDirection = null;
        switch (getDirection()) {
            case "north":
                if (moveWest()) {
                    setDirection("west");
                    shiftDirection = "east";
                } else if (moveNorth()) {
                    setDirection("north");
                    shiftDirection = "south";
                } else if (moveEast()) {
                    setDirection("east");
                    shiftDirection = "west";
                } else {
                    moveSouth();
                    setDirection("south");
                    shiftDirection = "north";
                }
                break;
            case "east":
                if (moveNorth()) {
                    setDirection("north");
                    shiftDirection = "south";
                } else if (moveEast()) {
                    setDirection("east");
                    shiftDirection = "west";
                } else if (moveSouth()) {
                    setDirection("south");
                    shiftDirection = "north";
                } else {
                    moveWest();
                    setDirection("west");
                    shiftDirection = "east";
                }
                break;
            case "south":
                if (moveEast()) {
                    setDirection("east");
                    shiftDirection = "west";
                } else if (moveSouth()) {
                    setDirection("south");
                    shiftDirection = "north";
                } else if (moveWest()) {
                    setDirection("west");
                    shiftDirection = "east";
                } else {
                    moveNorth();
                    setDirection("north");
                    shiftDirection = "south";
                }
                break;
            case "west":
                if (moveSouth()) {
                    setDirection("south");
                    shiftDirection = "north";
                } else if (moveWest()) {
                    setDirection("west");
                    shiftDirection = "east";
                } else if (moveNorth()) {
                    setDirection("north");
                    shiftDirection = "south";
                } else {
                    moveEast();
                    setDirection("east");
                    shiftDirection = "west";
                }
                break;
            default:
                System.out.println("We got a problem");
                break;
        }
        return shiftDirection;
    }
}
