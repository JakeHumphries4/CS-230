/**
 * This class is for creating a line enemy.
 *
 * @author Thomas Williams
 * @version 2.3
 */
public class StraightLineEnemy extends Navigator {
    //The direction the enemy is currently travelling, given by north, east south or west.
    private String direction;

    /**
     * Creates an instance of the StraightLineEnemy class
     *
     * @param direction takes in the enemies direction
     */
    public StraightLineEnemy(Cell cell, String direction) {
        super(cell);
        this.direction = direction;
    }

    /**
     * This method will return the direction of the enemy
     *
     * @return the current direction of the enemy
     */
    public String getDirection() {
        return direction;
    }

    /**
     * This method will set the direction of the enemy
     *
     * @param direction The enemies direction
     */
    public void setDirection(String direction) {
        this.direction = direction;
    }

    /**
     * The method will check the cell in front, if
     * it is ground then it moves forward, otherwise it
     * turns around and moves in that direction.
     */
    public String move() {
        //Direction the sprites will be shifted when moving.
        String shiftDirection = null;
        if (getDirection().equals("north")) {
            if (moveNorth()) {
                shiftDirection = "south";
            } else {
                setDirection("south");
                moveSouth();
                shiftDirection = "north";
            }
        } else if (getDirection().equals("south")) {
            if (moveSouth()) {
                shiftDirection = "north";
            } else {
                setDirection("north");
                moveNorth();
                shiftDirection = "south";
            }
        } else if (getDirection().equals("east")) {
            if (moveEast()) {
                shiftDirection = "west";
            } else {
                setDirection("west");
                moveWest();
                shiftDirection = "east";
            }
        } else if (getDirection().equals("west")) {
            if (moveWest()) {
                shiftDirection = "east";
            } else {
                setDirection("east");
                moveEast();
                shiftDirection = "west";
            }
        } else {
            System.out.println("We got a problem");
        }
        return shiftDirection;
    }
}