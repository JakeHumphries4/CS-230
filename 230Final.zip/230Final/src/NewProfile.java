import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 * This class implements the new profile window and creates a new profile.
 *
 * @author ciara
 */
public class NewProfile extends Application {

    final String FILENAME = "Player.txt";
    final StackPane rootPane = new StackPane();
    String character = "default";

    /**
     * Create new profile window by adding each attribute to the stackplane .
     *
     * @param primaryStage - the main window.
     */
    @Override
    public void start(Stage primaryStage) {

        BackgroundImage backgroundImage = new BackgroundImage(new Image("mainmenuwall.png"),
                BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        Label gameTitle = new Label();
        gameTitle.setText("Create New Player");
        gameTitle.setStyle(" -fx-text-fill: white; -fx-font-weight: bold");
        gameTitle.setFont(new Font("Copperplate Gothic Bold", 60));

        StackPane.setMargin(gameTitle, new Insets(0, 0, 390, 0));

        Button selectionOneBtn = new Button();
        Button selectionTwoBtn = new Button();
        Button selectionThreeBtn = new Button();
        Button selectionFourBtn = new Button();
        Button selectionFiveBtn = new Button();

        Image img1 = new Image("llama.png");
        selectionOneBtn.setGraphic(new ImageView(img1));
        selectionOneBtn.setStyle("-fx-border-color:green;");

        Image img2 = new Image("thugllama.png");
        selectionTwoBtn.setGraphic(new ImageView(img2));

        Image img3 = new Image("chefllama.png");
        selectionThreeBtn.setGraphic(new ImageView(img3));

        Image img4 = new Image("sombrerollama.png");
        selectionFourBtn.setGraphic(new ImageView(img4));

        Image img5 = new Image("fancyllama.png");
        selectionFiveBtn.setGraphic(new ImageView(img5));

        Label label1 = new Label("UserName: ");
        TextField nameFld = new TextField();
        Label label2 = new Label("");
        Label selectionLbl = new Label("");
        Button saveBtn = new Button("SAVE");
        Button nextBtn = new Button("NEXT");

        Button back = new Button("BACK");


        selectionLbl.setStyle("-fx-font-size: 15px; -fx-text-fill: white;");
        label1.setStyle("-fx-font-size: 15px; -fx-text-fill: white;");
        selectionFourBtn.setStyle("-fx-border-color:green;");
        selectionTwoBtn.setStyle("-fx-border-color:green;");
        selectionThreeBtn.setStyle("-fx-border-color:green;");
        selectionOneBtn.setStyle("-fx-border-color:green;");
        label2.setStyle("-fx-font-size: 15px; -fx-text-fill: white;");
        selectionFiveBtn.setStyle("-fx-border-color:green;");
        saveBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");
        nextBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");
        back.setStyle("-fx-background-color: transparent;-fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0");

        HBox selectionbuttons = new HBox();
        selectionbuttons.setSpacing(10);
        selectionbuttons.setPadding(new Insets(100, 0, 0, 120));
        selectionbuttons.getChildren().addAll(selectionOneBtn, selectionTwoBtn, selectionThreeBtn, selectionFourBtn, selectionFiveBtn);
        rootPane.setBackground(new Background(backgroundImage));
        rootPane.getChildren().add(gameTitle);
        rootPane.getChildren().add(selectionbuttons);
        rootPane.getChildren().add(nameFld);
        rootPane.getChildren().add(label1);
        rootPane.getChildren().add(back);
        rootPane.getChildren().add(saveBtn);
        rootPane.getChildren().add(selectionLbl);
        rootPane.getChildren().add(label2);

        StackPane.setMargin(label1, new Insets(100, 200, 0, -100));
        nameFld.setMaxWidth(200);
        StackPane.setMargin(nameFld, new Insets(100, 0, 0, 0));
        StackPane.setMargin(nextBtn, new Insets(300, 0, 0, 0));
        StackPane.setMargin(back, new Insets(-380, 800, 0, 0));
        StackPane.setMargin(saveBtn, new Insets(100, -200, 0, 100));
        StackPane.setMargin(selectionLbl, new Insets(0, 0, 0, 0));
        StackPane.setMargin(label2, new Insets(200, 0, 0, 0));
        label2.setVisible(false);

        /**
         * Action for the back button to return to the existing profile page.
         */

        back.setOnAction(e -> {
            Menu mainMenu = new Menu();
            primaryStage.getScene().setRoot(mainMenu.getRootPane(primaryStage));
        });
        /**
         * Action for the select button to show you have selected that character.
         */

        selectionOneBtn.setOnAction(e -> {
            character = "llama";
            selectionLbl.setText("You have selected " + character);

        });
        /**
         * Action for the select button to show you have selected that character.
         */
        selectionTwoBtn.setOnAction(e -> {
            character = "thugllama";
            System.out.print(character);
            selectionLbl.setText("You have selected " + character);

        });
        /**
         * Action for the select button to show you have selected that character.
         */
        selectionThreeBtn.setOnAction(e -> {
            character = "chefllama";
            selectionLbl.setText("You have selected " + character);
        });

        /**
         * Action for the select button to show you have selected that character.
         */
        selectionFourBtn.setOnAction(e -> {
            character = "sombrerollama";
            selectionLbl.setText("You have selected " + character);
        });

        /**
         * Action for the select button to show you have selected that character.
         */
        selectionFiveBtn.setOnAction(e -> {
            character = "fancyllama";
            selectionLbl.setText("You have selected " + character);
        });


        /**
         * Action for the save button to save the new profile to the file.
         */
        saveBtn.setOnAction(new EventHandler<ActionEvent>() {
            String userName = nameFld.getText();

            @Override
            public void handle(ActionEvent e) {

                if (!(nameFld.getText()).isEmpty()) {
                    if (!(character.equals("default"))) {
                        if (!(usernameComparison(nameFld.getText(),label2))) {
                            save(nameFld.getText(), character,label2);
                            Profile p = new Profile(nameFld.getText(),"0",character);
                            label2.setVisible(false);
                            //label2.setText("");
                            rootPane.getChildren().add(nextBtn);
                            StackPane.setMargin(nextBtn, new Insets(200, 0, 0, 0));
                            nameFld.setEditable(false);

                        } else {
                            label2.setVisible(true);

                        }
                    } else {
                        label2.setText("You have not picked a character");
                    }
                } else {
                    label2.setText("You have not left a username");
                    selectionLbl.setText("You have selected " + character);
                }
            }
        });
        nextBtn.setOnAction(e -> {
            Profile player = new Profile(nameFld.getText(),"0",character);
            LevelSelect.currentPlayer =player;
            LevelSelect level = new LevelSelect();

            primaryStage.getScene().setRoot(level.getRootPane(primaryStage));

        });
    }

    /**
     * method to run the start method.
     *
     * @param primaryStage - the main window.
     * @return rootPane - the pane on the canvas.
     */
    public Pane getRootPane(Stage primaryStage) {
        start(primaryStage);
        return rootPane;
    }

    /**
     * Method to save new name to file.
     *
     * @param uName     - The new name of the profile.
     * @param character - The character selected for the profile.
     * @param label2    - the label which is shown on the canvas.
     */
    public void save(String uName, String character,Label label2) {
        try {
            FileWriter writer = new FileWriter(FILENAME, true);
            writer.write( "\n"+uName +","+ "0" + ","+character );
            writer.flush();
            writer.close();
        } catch (IOException ex) {
            label2.setText("Saving Failed");
        }

    }

    /**
     * Method to check if the name entered has already been used.
     *
     * @param uName  - The new name which is being entered.
     * @param label2 - the label which is shown on the canvas.
     * @return uFound - boolean to show if name is found or not.
     */
    public Boolean usernameComparison(String uName,Label label2) {
        String[] info;
        String check;
        boolean uFound = false;

        int username = 0;
        int existingUsers = 0;

        File fileName = new File(FILENAME);
        Scanner in = null;
        Scanner input = null;

        try {
            in = new Scanner(fileName);
            if (!checkNum(label2)) {
                System.out.print(in.hasNext());

                while (in.hasNext()) {
                    String line[] = in.next().split(",");
                    check = line[0];
                    System.out.print(check);

                    if (check.equalsIgnoreCase(uName)) {
                        System.out.print("bryony");
                        uFound = true;
                        label2.setText("UserName Already Taken, Cannot Save, Try Again");
                    }
                }
            }else{
                uFound =true;
                label2.setText("There are too many current users,Delete one to continue");

            }
        } catch (FileNotFoundException e) {
            System.out.print("failed");
        }

        return uFound;
    }

    /**
     * Method to check if how many profiles have already been saved.
     *
     * @param label2 - the label which is shown on the canvas.
     * @return numOfProfile - number of profiles which are already saved.
     */

    public Boolean checkNum(Label label2) {
        Boolean numOfProfile = true;
        File fileName = new File(FILENAME);
        Scanner in1 = null;
        try {
            in1 = new Scanner(fileName);
            int count = 0;
            while (in1.hasNextLine()) {
                in1.nextLine();
                count++;
            }
            if (count < 5){
                numOfProfile = false;
            }else{
                numOfProfile = true;
                label2.setText("There are too many current users,Delete one to continue");

            }
        } catch (FileNotFoundException e) {
            System.out.print("failed");

        }

        return numOfProfile;
    }
}
