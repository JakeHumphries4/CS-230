import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

/**
 * Sprite is a class that is represents the objects that need to be rendered.
 *
 * @author Jake
 * @version 1.3
 */
public class Sprite {
    private Image image;
    private double positionX;
    private double positionY;
    private double width;
    private double height;
    private String type;

    /**
     * Creates an instance of the sprite
     *
     * @param posX  - The xposition of the image on screen
     * @param posY  - The yposition of the image on screen
     * @param image - the Image that the sprite will use to display
     * @param type  - the type of sprite that is created
     */

    public Sprite(int posX, int posY, Image image, String type) {
        this.positionX = posX;
        this.positionY = posY;
        this.image = image;
        this.width = image.getWidth();
        this.height = image.getHeight();
        this.type = type;
    }

    /**
     * Creates an instance of the sprite
     *
     * @param posX - The xposition of the image on screen
     * @param posY - The yposition of the image on screen
     */

    public Sprite(int posX, int posY) {
        this.positionX = posX;
        this.positionY = posY;
        this.type = type;
    }

    /**
     * Moves the sprite in a given direction
     *
     * @param dir  String - the direction for the sprite to move
     * @param dist The distance in pixels for the sprite to move
     */
    public void move(String dir, int dist) {
        if (dir.equals("north")) {
            this.positionY += dist;
        }
        if (dir.equals("south")) {
            this.positionY += -dist;
        }
        if (dir.equals("east")) {
            this.positionX += -dist;
        }
        if (dir.equals("west")) {
            this.positionX += dist;
        }
    }

    /**
     * Sets the image of the sprite
     *
     * @param image - the Image that the sprite will use to display
     */
    public void setImage(Image image) {
        this.image = image;
        this.width = image.getWidth();
        this.height = image.getHeight();
    }

    /**
     * Gets the type of the Sprite
     *
     * @return type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type of the image
     *
     * @param type a string representing the type of sprite
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * adds a value to the current x coordinate of the sprite
     *
     * @param x the value to be added
     */
    public void addPositionX(double x) {
        this.positionX += x;
    }

    /**
     * adds a value to the current y coordinate of the sprite
     *
     * @param y the value to be added
     */
    public void addPositionY(double y) {
        this.positionY += y;
    }

    /**
     * Renders the sprite onto the screen
     *
     * @param gc a reference to the games GrahpicsContext instance
     */
    public void render(GraphicsContext gc) {
        gc.drawImage(this.image, this.positionX, this.positionY);
    }

    /**
     * Returns the hitbox of the sprite based on its position, and size
     *
     * @return a Rectangle2D instance of the hitbox
     */
    public Rectangle2D getBoundary() {
        return new Rectangle2D(this.positionX, this.positionY, this.width, this.height);
    }

    /**
     * Uses the Rectangle2D objects of this Sprite object and another to see if they overlap
     *
     * @param s a Sprite object to check for collision
     * @return true/false based on if they intersect
     */
    public boolean intersects(Sprite s) {
        return s.getBoundary().intersects(this.getBoundary());
    }

    /**
     * Gets the current x coordinate
     *
     * @return current x coordinate
     */
    public double getPositionX() {
        return positionX;
    }

    /**
     * Sets the position of the x coordinate of the sprite
     *
     * @param positionX the position to set it to
     */
    public void setPositionX(double positionX) {
        this.positionX = positionX;
    }

    /**
     * Gets the current y coordinate
     *
     * @return current y coordingate
     */
    public double getPositionY() {
        return positionY;
    }

    /**
     * Sets the position of the y coordinate of the sprite
     *
     * @param positionY the position to set it to
     */
    public void setPositionY(double positionY) {
        this.positionY = positionY;
    }

    /**
     * toString method to return data as a string
     *
     * @return String of the object data
     */
    public String toString() {
        return " Position: [" + positionX + "," + positionY + "]\n SpriteType: " + type;
    }
}