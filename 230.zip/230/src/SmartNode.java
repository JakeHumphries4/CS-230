/**
 * Class used for nodes when calculating the shortest path to the player from the smart enemies.
 * @author Johannes Zischka
 * @version 1.2
 */
public class SmartNode {
    private Cell cell;
    private SmartNode previous;

    /**
     * Creates a node for the given cell in a shortest path.
     * @param cell The cell that this node represents.
     * @param previous The previous node in the shortest path.
     */
    public SmartNode(Cell cell, SmartNode previous) {
        this.cell = cell;
        this.previous = previous;
    }


    /**
     * Gets the cell that this node represents.
     * @return The cell with the data in in..
     */
    public Cell getCell() {
        return cell;
    }

    /**
     * Sets the cell that this node represents.
     * @param cell The cell with the data in in..
     */
    public void setCell(Cell cell) {
        this.cell = cell;
    }

    /**
     * Gets the previous node in the shortest path that this node is part of.
     * @return The previous node in the shortest path.
     */
    public SmartNode getPrevious() {
        return previous;
    }

    /**
     * Sets the previous node in the shortest path that this node is part of.
     * @param previous The previous node in the shortest path.
     */
    public void setPrevious(SmartNode previous) {
        this.previous = previous;
    }
}
