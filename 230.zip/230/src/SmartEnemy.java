/**
 * Enemy that uses pathfinding to go around obstacles and kill the player.
 * @author Johannes
 * @version 1.4
 */
import java.util.ArrayList;
import java.util.LinkedList;

public class SmartEnemy extends Navigator {

    /**
     * Instantiates the smart enemy with the cell it starts on.
     * @param cell The cell the enemy starts on.
     */
    public SmartEnemy(Cell cell) {
        super(cell);
    }

    /**
     * Calculates the next move that the smart enemy needs to make to get closer to the player.
     * @param targetX The x-coordinate of the player.
     * @param targetY The y-coordinate of the player.
     * @return The direction the smart enemy should move next.
     */
    private String findNextMove(int targetX, int targetY) {
        ArrayList<SmartNode> visited = new ArrayList<>();
        LinkedList<SmartNode> unvisited = new LinkedList<>();
        SmartNode currentNode = new SmartNode(getCell(), null);
        unvisited.add(currentNode);
        boolean pathFound = false;
        while (!pathFound) {
            currentNode = unvisited.removeFirst();;
            Cell currentCell = currentNode.getCell();
            if (currentCell.getxCoord() == targetX && currentCell.getyCoord() == targetY) {
                pathFound = true;
            } else {
                Cell north = currentCell.getNorth();
                Cell east = currentCell.getEast();
                Cell south = currentCell.getSouth();
                Cell west = currentCell.getWest();
                //if (visited.contains(north) || visited.contains(south) || visited.contains(east) || visited.contains(west)) {
                for (SmartNode visitedNode : visited) {
                    Cell visitedCell = visitedNode.getCell();
                    if (north == visitedCell) {
                        north = null;
                    }
                    if (south == visitedCell) {
                        south = null;
                    }
                    if (east == visitedCell) {
                        east = null;
                    }
                    if (west == visitedNode.getCell()) {
                        west = null;
                    }
                }
                if (north != null && north.getCellType().equals("ground")) {
                    unvisited.add(new SmartNode(north, currentNode));
                }
                if (east != null && east.getCellType().equals("ground")) {
                    unvisited.add(new SmartNode(east, currentNode));
                }
                if (south != null && south.getCellType().equals("ground")) {
                    unvisited.add(new SmartNode(south, currentNode));
                }
                if (west != null && west.getCellType().equals("ground")) {
                    unvisited.add(new SmartNode(west, currentNode));
                }
                visited.add(currentNode);
            }
        }
        while (currentNode.getPrevious().getCell() != getCell()) {
            currentNode = currentNode.getPrevious();
        }
        return this.getCell().getDirection(currentNode.getCell());
    }

    /**
     * Moves the enemy closer to the player.
     * @param playerX The x-coordinate of the player.
     * @param playerY The y-coordinate of the player.
     * @return The direction the sprite needs to be shifted.
     */
    public String move(int playerX, int playerY) {
        String shiftDirection = null;
        String move = findNextMove(playerX, playerY);
        switch (move) {
            case "north":
                moveNorth();
                shiftDirection = "south";
                break;
            case "east":
                moveEast();
                shiftDirection = "west";
                break;
            case "south":
                moveSouth();
                shiftDirection = "north";
                break;
            case "west":
                moveWest();
                shiftDirection = "east";
                break;
        }
        return shiftDirection;
    }
}
