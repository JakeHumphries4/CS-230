public class Teleport extends Cell
{
    Teleport pair;
    private String number;

    public Teleport(int xCoord, int yCoord, String number)
    {
        super(xCoord,yCoord, "teleport");
        this.pair = null;
        this.number = number;
    }

    public Teleport(int xCoord, int yCoord, Teleport pair)
    {
        super(xCoord,yCoord, "teleport");
        this.pair = pair;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Teleport getPair()
    {
        return pair;
    }

    public void setPair(Teleport pair)
    {
        this.pair = pair;
    }

}

