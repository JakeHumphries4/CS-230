/**
 * This class creates a key door.
 * @author Ruth Maycock
 * @version 1.1
 */
public class KeyDoor extends Cell {

    private String tool; //The tool of the door

    /**
     * Creates a key door with its x and y coordinates along with the tool of the door.
     * @param xCoord The x coordinate.
     * @param yCoord The y coordinate.
     * @param tool The tool of the door.
     */
    public KeyDoor(int xCoord, int yCoord, String tool) {
        super(xCoord, yCoord, "keyDoor"+tool);

        this.tool = tool;
    }

    /**
     * Get the tool of the door
     * @return The tool of the chosen door
     */
    public String getTool() {
        return tool;
    }

    /**
     * Set the tool of the door
     * @param tool The tool chosen for this door
     */
    public void setTool(String tool) {
        this.tool = tool;
    }
}
