/**
 * The game is split into cells that may or may not be able to be walked on by navigators(players and enemies).
 * Each of these cells have coordinates, and can find neighbouring cells.
 * @author Ruth, Jake and Johannes
 * @version 1.8
 */
public class Cell {
    private int xCoord;
    private int yCoord;
    private Cell north;
    private Cell east;
    private Cell south;
    private Cell west;
    private String cellType;

    /**
     *
     * @param xCoord The x Coordinate of the cell.
     * @param yCoord The y coordinate of the cell.
     * @param cellType the type of cell ie. goal, token door, ground etc.
     */
    public Cell(int xCoord, int yCoord, String cellType) {
        this.xCoord = xCoord;
        this.yCoord = yCoord;
        this.cellType = cellType;
    }

    /**
     * Gets in which direction a referenced cell neighbours this cell.
     * @param otherCell the neighbouring cell.
     * @return a direction: north, east, south, west.
     */
    public String getDirection(Cell otherCell) {
        if (otherCell == north) {
            return "north";
        } else if (otherCell == east) {
            return "east";
        } else if (otherCell == south) {
            return "south";
        } else if (otherCell == west) {
            return "west";
        } else {
            return null;
        }
    }

    /**
     * Gets the x-coordinate of the cell.
     * @return The xcoord of this cell.
     */
    public int getxCoord() {
        return xCoord;
    }

    /**
     * Sets the x-coordinate of the cell.
     * @param xCoord The new xcoord.
     */
    public void setxCoord(int xCoord) {
        this.xCoord = xCoord;
    }

    /**
     * Gets the y-coordinate of the cell.
     * @return The ycoord of the cell.
     */
    public int getyCoord() {
        return yCoord;
    }

    /**
     * Sets the y-coordinate of the cell.
     * @param yCoord The new ycoord.
     */
    public void setyCoord(int yCoord) {
        this.yCoord = yCoord;
    }

    /**
     * Gets the neighbouring cell north of this cell.
     * @return The neighbouring cell.
     */
    public Cell getNorth() {
        return north;
    }

    /**
     * Sets the neighbouring cell north of this cell.
     * @param north The new neighbouring cell.
     */
    public void setNorth(Cell north) {
        this.north = north;
    }

    /**
     * Gets the neighbouring cell east of this cell
     * @return The neighbouring cell.
     */
    public Cell getEast() {
        return east;
    }

    /**
     * Sets the neighbouring cell east of this cell.
     * @param east The new neighbouring cell.
     */
    public void setEast(Cell east) {
        this.east = east;
    }

    /**
     * Gets the neighbouring cell south of this cell.
     * @return The neighbouring cell.
     */
    public Cell getSouth() {
        return south;
    }

    /**
     * Sets the neighbouring cell south of this cell.
     * @param south The new neighbouring cell.
     */
    public void setSouth(Cell south) {
        this.south = south;
    }

    /**
     * Gets the neighbouring cell west of this cell.
     * @return The neighbouring cell.
     */
    public Cell getWest() {
        return west;
    }

    /**
     * Sets the neighbouring cell west of this cell.
     * @param west The new neighbouring cell.
     */
    public void setWest(Cell west) {
        this.west = west;
    }

    /**
     * Gets the type of this cell.
     * @return The cell type.
     */
    public String getCellType() {
        return cellType;
    }

    /**
     * Sets what type of cell this is.
     * @param cellType The cell type.
     */
    public void setCellType(String cellType) {
        this.cellType = cellType;
    }
}
