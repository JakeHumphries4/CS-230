/**
 * Creates a new user Profile.
 * @author Ciara
 * version 1.5
 */

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.*;
import java.util.Scanner;

public class NewProfile extends Application
{

    final String FILENAME = "Player.txt";
    final StackPane rootPane = new StackPane();
    String character = "default";

    @Override
    public void start(Stage primaryStage)
    {

        BackgroundImage backgroundImage = new BackgroundImage(new Image("mainmenuwall.png"),
                BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        rootPane.setBackground(new Background(backgroundImage));

        Label gameTitle = new Label();
        gameTitle.setText("Create New Player");
        //gameTitle.setWrapText(true);
        gameTitle.setStyle(" -fx-text-fill: white; -fx-font-weight: bold");
        gameTitle.setFont(new Font("Copperplate Gothic Bold", 60));

        StackPane.setMargin(gameTitle, new Insets(0, 0, 390, 0));
        rootPane.getChildren().add(gameTitle);

        Button selectionOneBtn = new Button();
        Button selectionTwoBtn = new Button();
        Button selectionThreeBtn = new Button();
        Button selectionFourBtn = new Button();
        Button selectionFiveBtn = new Button();

        Image img1 = new Image("llama.png");
        selectionOneBtn.setGraphic(new ImageView(img1));
        selectionOneBtn.setStyle("-fx-border-color:green;");

        Image img2 = new Image("thugllama.png");
        selectionTwoBtn.setGraphic(new ImageView(img2));
        selectionTwoBtn.setStyle("-fx-border-color:green;");

        Image img3 = new Image("chefllama.png");
        selectionThreeBtn.setGraphic(new ImageView(img3));
        selectionThreeBtn.setStyle("-fx-border-color:green;");

        Image img4 = new Image("sombrerollama.png");
        selectionFourBtn.setGraphic(new ImageView(img4));
        selectionFourBtn.setStyle("-fx-border-color:green;");

        Image img5 = new Image("fancyllama.png");
        selectionFiveBtn.setGraphic(new ImageView(img5));
        selectionFiveBtn.setStyle("-fx-border-color:green;");

        Label label1 = new Label("UserName: ");
        TextField nameFld = new TextField();
        Label label2 = new Label("");
        Label selectionLbl = new Label("");
        Button saveBtn = new Button("SAVE");
        Button nextBtn = new Button("NEXT");

        Button back = new Button();
        back.setText("BACK");
        back.setStyle("-fx-background-color: transparent;-fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0");

        selectionLbl.setStyle("-fx-font-size: 15px; -fx-text-fill: white;");
        label1.setStyle("-fx-font-size: 15px; -fx-text-fill: white;");
        label2.setStyle("-fx-font-size: 15px; -fx-text-fill: white;");
        saveBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");
        nextBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");

        HBox selectionbuttons = new HBox();
        selectionbuttons.setSpacing(10);
        selectionbuttons.setPadding(new Insets(100, 0, 0, 120));
        selectionbuttons.getChildren().addAll(selectionOneBtn, selectionTwoBtn, selectionThreeBtn, selectionFourBtn, selectionFiveBtn);
        rootPane.getChildren().add(selectionbuttons);

        rootPane.getChildren().add(label1);
        StackPane.setMargin(label1, new Insets(100, 200, 0, -100));
        rootPane.getChildren().add(nameFld);
        nameFld.setMaxWidth(200);

        StackPane.setMargin(nameFld, new Insets(100, 0, 0, 0));

        //rootPane.getChildren().add(nextBtn);//set invisible before submission
        StackPane.setMargin(nextBtn, new Insets(300, 0, 0, 0));

        rootPane.getChildren().add(back);
        StackPane.setMargin(back, new Insets(-380, 800, 0, 0));

        rootPane.getChildren().add(saveBtn);
        StackPane.setMargin(saveBtn, new Insets(100, -200, 0, 100));


        rootPane.getChildren().add(selectionLbl);
        StackPane.setMargin(selectionLbl, new Insets(0, 0, 0, 0));
        rootPane.getChildren().add(label2);
        StackPane.setMargin(label2, new Insets(200, 0, 0, 0));
        label2.setVisible(false);

        back.setOnAction(e ->
        {
            Menu mainMenu = new Menu();
            primaryStage.getScene().setRoot(mainMenu.getRootPane(primaryStage));
        });

        selectionOneBtn.setOnAction(e ->
        {
            character = "llama";
            selectionLbl.setText("You have selected " + character);

        });
        selectionTwoBtn.setOnAction(e ->
        {
            character = "thugllama";
            System.out.print(character);
            selectionLbl.setText("You have selected " + character);

        });
        selectionThreeBtn.setOnAction(e ->
        {
            character = "chefllama";
            selectionLbl.setText("You have selected " + character);
        });
        selectionFourBtn.setOnAction(e ->
        {
            character = "sombrerollama";
            selectionLbl.setText("You have selected " + character);
        });
        selectionFiveBtn.setOnAction(e ->
        {
            character = "fancyllama";
            selectionLbl.setText("You have selected " + character);
        });


        saveBtn.setOnAction(new EventHandler<ActionEvent>()
        {
            String userName = nameFld.getText();

            @Override
            public void handle(ActionEvent e)
            {

                if (!(nameFld.getText()).isEmpty())
                {
                    if (!(character.equals("default")))
                    {
                        if (!(usernameComparison(nameFld.getText(), label2)))
                        {
                            save(nameFld.getText(), character, label2);
                            Profile p = new Profile(nameFld.getText(), "0", character);

                            label2.setText("*" + nameFld.getText() + " saved, click next * ");
                            rootPane.getChildren().add(nextBtn);
                            StackPane.setMargin(nextBtn, new Insets(200, 0, 0, 0));
                            nameFld.setEditable(false);

                        } else
                        {
                            label2.setVisible(true);

                        }
                    } else
                    {
                        label2.setText("You have not picked a character");
                    }
                } else
                {
                    label2.setText("You have not left a username");
                    selectionLbl.setText("You have selected " + character);
                }
            }
        });
        nextBtn.setOnAction(e ->
        {
            Profile player = new Profile(nameFld.getText(), "0", character);
            LevelSelect.currentPlayer = player;
            LevelSelect level = new LevelSelect();

            primaryStage.getScene().setRoot(level.getRootPane(primaryStage));

        });
    }

    public Pane getRootPane(Stage primaryStage)
    {
        start(primaryStage);
        return rootPane;
    }

    /**
     * Saves a new user to a the given file.
     *
     * @param uName     Profile username chosen.
     * @param character Character chosen to play as.
     * @param label2
     */
    public void save(String uName, String character, Label label2)
    {
        try
        {
            FileWriter writer = new FileWriter(FILENAME, true);
            writer.write(uName + " " + "0" + " " + character + "\n");
            writer.flush();
            writer.close();
        } catch (IOException ex)
        {
            label2.setText("Saving Failed");
        }

    }

    /**
     * Compares existing usernames of profiles to a given username in order to check that it hasn't been used before.
     *
     * @param uName  Given username.
     * @param label2
     * @return True or false.
     */
    public Boolean usernameComparison(String uName, Label label2)
    {
        String[] info;
        String check;
        boolean uFound = false;

        int username = 0;
        int existingUsers = 0;

        File fileName = new File(FILENAME);
        Scanner in = null;

        try
        {
            in = new Scanner(fileName);
            if (!checkNum(in, label2))
            {
                System.out.print("Help");

                while (in.hasNext())
                {
                    check = in.next();
                    if (check.equalsIgnoreCase(uName))
                    {
                        uFound = true;
                        label2.setText("UserName Already Taken, Cannot Save, Try Again");
                    }
                }
            } else
            {
                uFound = true;
                label2.setText("There are too many current users,Delete one to continue");

            }
        } catch (FileNotFoundException e)
        {
            System.out.print("failed");
        }

        return uFound;
    }

    /**
     * Checks if the maximum number of profiles has been reached or not.
     *
     * @param in
     * @param label2
     * @return True or False.
     */
    public Boolean checkNum(Scanner in, Label label2)
    {

        Boolean numOfProfile = true;
        File file = new File(FILENAME);
        try (Scanner sc = new Scanner(new FileInputStream(file)))
        {
            int count = 0;
            while (in.hasNextLine())
            {
                in.nextLine();
                count++;
            }
            if (count < 5)
            {
                numOfProfile = false;
            } else
            {
                numOfProfile = true;
                label2.setText("There are too many current users,Delete one to continue");

            }
        } catch (FileNotFoundException e)
        {
            e.printStackTrace();

        }

        return numOfProfile;
    }
}
