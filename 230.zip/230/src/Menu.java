
/**
 *
 * This class represents the java fx of the main menu window.
 *
 *   @author Bryony Hughes
 *
 *   @version 1.1
 *
 */

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class Menu extends Application {

    /**
     *
     * Main method to launch the class.
     *
     */
    final StackPane rootPane = new StackPane(); // the root pane used to

    public static void main(String[] args) {

        launch(args);

    }

    @Override

    /**
     *
     * Create main menu by adding each attribute to the stackplane .
     *
     * @param primarystage the main window.
     *
     */
    public void start(Stage primaryStage) {
        primaryStage.getIcons().add(new Image("llamaicon.png"));

        MessageOfTheDay messageOfTheDay = new MessageOfTheDay();

        messageOfTheDay.main(null);

        // creating all the titles, buttons ect
        primaryStage.setTitle("Llama Prison Drama");

        Button createNewProfile = new Button();

        createNewProfile.setText("  CREATE NEW PROFILE   ");

        createNewProfile.setStyle("-fx-background-color: transparent;-fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0");
        //createNewProfile.setFont(new Font("Copperplate Gothic Bold",10));
        
        Button existingProfile = new Button();

        existingProfile.setText("SELECT EXISTING PROFILE");

        existingProfile.setStyle("-fx-background-color: transparent;-fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0");
         //existingProfile.setFont(new Font("Copperplate Gothic Bold",10));
        Label gameTitle = new Label();

        gameTitle.setText("Llama Prison Drama");

        gameTitle.setStyle(" -fx-text-fill: white; -fx-font-weight: bold;");
        gameTitle.setFont(new Font("Copperplate Gothic Bold",60));
        gameTitle.setWrapText(true);

        Label msgTitle = new Label();

        msgTitle.setText("Message Of The Day:");

        msgTitle.setStyle("-fx-font-size: 15px; -fx-text-fill: white;");
        msgTitle.setFont(new Font("Copperplate Gothic Bold",15));
        Label msgOfDay = new Label();

        msgOfDay.setText(messageOfTheDay.finalResult);

        msgOfDay.setWrapText(true);

        msgOfDay.setTextAlignment(TextAlignment.CENTER);

        msgOfDay.setStyle(" -fx-text-fill: white;");
msgOfDay.setFont(new Font("Copperplate Gothic Bold",15));
        // stacking everything onto the stack pane
        StackPane rootPane = new StackPane();

        BackgroundImage backgroundImage = new BackgroundImage(new Image("mainmenuwall.png"),
                BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        rootPane.setBackground(new Background(backgroundImage));

        Image img = new Image("mainmenullama.png");

        ImageView imgView = new ImageView(img);

        rootPane.getChildren().add(imgView);

        rootPane.getChildren().add(gameTitle);

        StackPane.setMargin(gameTitle, new Insets(0, 0, 390, 0));

        rootPane.getChildren().add(msgTitle);

        StackPane.setMargin(msgTitle, new Insets(380, 0, 0, 0));

        rootPane.getChildren().add(msgOfDay);

        StackPane.setMargin(msgOfDay, new Insets(440, 0, 0, 0));

        rootPane.getChildren().add(createNewProfile);

        StackPane.setMargin(createNewProfile, new Insets(270, 135, 0, 0));

        rootPane.getChildren().add(existingProfile);

        StackPane.setMargin(existingProfile, new Insets(270, 0, 0, 160));

        //actions for when the buttons are pressed
        createNewProfile.setOnAction(e -> {
            NewProfile player = new NewProfile();
            primaryStage.getScene().setRoot(player.getRootPane(primaryStage));
        });

        existingProfile.setOnAction(e -> {
            try
            {
                ExistingProfile player = new ExistingProfile();

                primaryStage.getScene().setRoot(player.getRootPane(primaryStage));
            }
            catch(Exception e1){
                System.out.println("couldn't load existing player - probably newLine in Player.txt");
            }

        });

        //creating the main window by setting the size ect
        Scene scene = new Scene(rootPane, 900, 500);

        primaryStage.setScene(scene);

        primaryStage.show();

    }

    public Pane getRootPane(Stage primaryStage) {

        start(primaryStage);

        return rootPane;

    }

}
