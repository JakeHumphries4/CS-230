/**
 * Contains data for a level being played in the game.
 * @author Ruth
 * @version 1.5
 */

import java.util.ArrayList;

public class Level {

    private ArrayList<Cell> cells;
    private ArrayList<Navigator> navigators;
    private int yDimensions;
    private int xDimensions;
    //Level number
    private int number;

    /**
     * Instantiates level array lists.
     */
    public Level() {
        cells = new ArrayList<>();
        navigators = new ArrayList<>();
    }

    /**
     * Gets a list of cells in the level.
     * @return Cells in the level.
     */
    public ArrayList<Cell> getCells()
    {
        return cells;
    }

    /**
     * Sets what cells are in the level.
     * @param cells List of cells.
     */
    public void setCells(ArrayList<Cell> cells)
    {
        this.cells = cells;
    }

    /**
     * Gets list of all navigators in the level.
     * @return Navigators in the level.
     */
    public ArrayList<Navigator> getNavigators()
    {
        return navigators;
    }

    /**
     * Sets list of navigators in the level.
     * @param navigators List of navigators.
     */
    public void setNavigators(ArrayList<Navigator> navigators)
    {
        this.navigators = navigators;
    }

    /**
     * Get number of cells tall the game is.
     * @return The levels y dimension.
     */
    public int getyDimensions()
    {
        return yDimensions;
    }

    /**
     * Set the number of cells tall the game is.
     * @param yDimensions The new y dimension of the game.
     */
    public void setyDimensions(int yDimensions)
    {
        this.yDimensions = yDimensions;
    }

    /**
     * Get the number of cells wide the level is.
     * @return The levels x dimension.
     */
    public int getxDimensions()
    {
        return xDimensions;
    }

    /**
     * Set the number of cells wide the level is.
     * @param xDimensions The new x dimension of the game.
     */
    public void setxDimensions(int xDimensions)
    {
        this.xDimensions = xDimensions;
    }

    /**
     * Add a new cell to the level.
     * @param newCell The new cell.
     */
    public void addCell(Cell newCell)
    {
        cells.add(newCell);
    }

    /**
     * Add a new navigator to the level.
     * @param newNavigator The new navigator.
     */
    public void addNavigator(Navigator newNavigator)
    {
        navigators.add(newNavigator);
    }

    /**
     * Get what number level in the game this level is.
     * @return The level number.
     */
    public int getNumber() {
        return number;
    }

    /**
     * Set the level number.
     * @param number The level number.
     */
    public void setNumber(int number) {
        this.number = number;
    }
}
