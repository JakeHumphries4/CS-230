/**
 * @author Ciara
 * @version 1.1
 */

import java.io.File;
class FileReader {
    public static void Save(Level l, Profile p) {
    }

    public FileReader(File fileName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
