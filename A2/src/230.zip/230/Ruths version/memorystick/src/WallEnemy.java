/**
 * This class is for creating a wall enemy.
 * @author Thomas Williams
 * @version 3.2
 */

public class WallEnemy extends Navigator {

	private String direction; //The current direction the enemy is travelling

	/**
	 * Constructor for a wall enemy
	 * @param direction The enemies current direction
	 */
	public WallEnemy(Cell cell, String direction) {
		super(cell); //Inherits coordinates from Navigator
		this.direction = direction;
	}

	/**
	 * This methods sets the direction of the enemy
	 * @param direction The new direction an enemy should travel
	 */
	public void setDirection(String direction) {
		this.direction = direction;
	}

	/**
	 * This method gets the enemies current direction
	 * @return The current direction
	 */
	public String getDirection() {
		return direction;
	}

	/**
	 * This method calculates the next move of the wall enemy,
	 * by calling methods from navigator in order to check
	 * for walls, allowing the enemy to move
	 */
	public void nextMove() {
		/*
		 * The method checks the cell to the left of the enemy,
		 * and moves if its a ground cell. If its not ground, then it
		 * will do the same for the cell in front, and if thats ground,
		 * it will check the cell to its right. If that to is ground, then it
		 * will move backwards, as it has reached a dead end.
		 */
		switch (getDirection()) {
			case "north":
				if (super.moveWest()) {
					setDirection("west");
				} else if (super.moveNorth()) {
					setDirection("north");
				} else if (super.moveEast()) {
					setDirection("east");
				} else {
					super.moveSouth();
					setDirection("south");
				}
				break;
			case "east":
				if (super.moveNorth()) {
					setDirection("north");
				} else if (super.moveEast()) {
					setDirection("east");
				} else if (super.moveSouth()) {
					setDirection("south");
				} else {
					super.moveWest();
					setDirection("west");
				}
				break;
			case "south":
				if (super.moveEast()) {
					setDirection("east");
				} else if (super.moveSouth()) {
					setDirection("south");
				} else if (super.moveWest()) {
					setDirection("west");
				} else {
					super.moveNorth();
					setDirection("north");
				}
				break;
			case "west":
				if (super.moveSouth()) {
					setDirection("south");
				} else if (super.moveWest()) {
					setDirection("west");
				} else if (super.moveNorth()) {
					setDirection("north");
				} else {
					super.moveEast();
					setDirection("east");
				}
				break;
			default:
				System.out.println("We got a problem");
				break;
		}
	}
}
