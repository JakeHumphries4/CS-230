import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 * Loads and saves levels from and to text files.
 * @author Ruth
 * @version 1.6
 */

public class LevelController {

    private Player player;
    private Level currentLevel;

    public LevelController() {
        currentLevel = new Level();
    }

    /**
     *
     * @param levelFile
     * @return
     */
    public Level loadLevel(String levelFile) {
        File file = new File(levelFile);
        try {
            Scanner in = new Scanner(file);
            currentLevel = readLevelFile(in, currentLevel);

        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return currentLevel;
    }

    /**
     *
     * @param in
     * @param level
     */
    private Level readLevelFile(Scanner in, Level level) {
        level.setNumber(in.nextInt());
        level.setxDimensions(in.nextInt());
        level.setyDimensions(in.nextInt());

        for (int y = 0; y < level.getyDimensions(); y++) {
            for (int x = 0; x < level.getxDimensions(); x++) {
                String label = in.next();
                Cell newCell = null;
                String other = "";
                if (label.length() > 1) {
                    //Second part of any symbol
                    other = label.substring(1);
                    label = label.substring(0, 1);
                }

                switch (label) {
                    case "#":
                        newCell = new Cell(x, y, "wall");
                        break;
                    case "m":
                        //Token cost
                        int tokenCost = Integer.parseInt(other);
                        newCell = new TokenDoor(x, y, tokenCost);
                        break;
                    case "k":
                        newCell = new KeyDoor(x, y, other);
                        break;
                    case "g":
                        newCell = new Cell(x, y, "goal");
                        break;
                    case "d":
                        newCell = new Cell(x, y, "dog");
                        break;
                    case "p":
                        newCell = new Cell(x, y, "prisoner");
                        break;
                    //TODO teleport instantiation
                    case "t":
                        newCell = new Teleport(x, y, other);
                        for (Cell cell:level.getCells()) {
                            if (cell.getCellType().equals("teleport")) {
                                Teleport tCell = (Teleport) cell;
                                if (tCell.getNumber().equals(other)) {
                                    tCell.setPair((Teleport)newCell);
                                    ((Teleport) newCell).setPair(tCell);

                                }
                            }
                        }
                        break;
                    case "$":
                        newCell = new Cell(x, y, "token");
                        break;
                    //keys for key doors
                    case "1":
                        newCell = new Cell(x, y, "1");
                        break;
                    case "2":
                        newCell = new Cell(x, y, "2");
                        break;
                    case "3":
                        newCell = new Cell(x, y, "3");
                        break;
                    case "b":
                        newCell = new Cell(x, y, "bone");
                        break;
                    case "c":
                        newCell = new Cell(x, y, "cigs");
                        break;
                    default:
                        newCell = new Cell(x, y, "ground");
                        break;
                }
                level.addCell(newCell);

                Navigator navigator = null;

                switch (label) {
                    case "P":
                        player = new Player(newCell);
                        level.addNavigator(player);
                        break;
                    case "D":
                        navigator = new DumbTargetingEnemy(newCell);
                        break;
                    case "L":
                        navigator = new StraightLineEnemy(newCell, convertDirection(other));
                        break;
                    case "W":
                        navigator = new WallEnemy(newCell, convertDirection(other));
                        break;
                    case "S":
                        navigator = new SmartEnemy(newCell);
                        break;
                    default:
                }
                if (navigator != null) {
                    level.addNavigator(navigator);
                }
            }
        }
        if (in.hasNext()) {
            player.setTokens(in.nextInt());
            setPlayerInventory(in, player);
            player.setTimePlayed(in.nextLong());
            //TODO set start time and stop time elsewhere in game
        } else {
            in.close();
        }return level;
    }

    private String convertDirection(String direction) {
        switch (direction) {
            case "n":
                direction = "north";
                break;
            case "e":
                direction = "east";
                break;
            case "s":
                direction = "south";
                break;
            case "w":
                direction = "west";
                break;
            default:
                direction = null;
        }
        return direction;
    }

    private void setPlayerInventory(Scanner in, Player player) {
        String label;
        String collectable = null;
        do {
            label = in.next();
            switch (label) {
                case "1":
                    collectable = "1";
                    break;
                case "2":
                    collectable = "2";
                    break;
                case "3":
                    collectable = "3";
                    break;
                case "bone":
                    collectable = "bone";
                    break;
                case "cigs":
                    collectable = "cigs";
                    break;
                default:

            }
            player.addInventory(collectable);
        } while (in.hasNext());
    }

    public String saveLevel(Level level, Player player) {
        return "failed";
    }

    private void writeLevelFile(Level level, Player player, String fileName) {
        try {
            FileWriter out = new FileWriter("Level_Files/" + fileName);
            String[][] levelArray = levelToArray(level);
            out.write(level.getNumber() + "\n");
            out.write(level.getxDimensions() + " ");
            out.write(level.getyDimensions());
            for (int y = 0; y < level.getyDimensions(); y++) {
                for (int x = 0; x < level.getxDimensions(); x++)
                {
                    out.write(levelArray[x][y] + " ");
                }
                out.write("\n");
            }
            out.write(player.getTokens() + "\n");
            for (String collectable : player.getInventory()) {
                String label = collectable.substring(0, 1);
                out.write(label + " ");
            }
            out.write("\n" + player.getTimePlayed());
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String[][] levelToArray(Level level) {
        String[][] array = new String[level.getxDimensions()][level.getyDimensions()];
        array = cellsToArray(level, array);
        array = navigatorsToArray(level, array);
        return array;
    }

    private String[][] cellsToArray(Level level, String[][] array) {
        for (Cell cell : level.getCells()) {
            String cellType = cell.getCellType();
            String label = null;
            switch (cellType) {
                case "ground":
                    label = "-";
                    break;
                case "goal":
                    label = "g";
                    break;
                case "keyDoor":
                    label = "k" + cell.getCellType();
                    break;
                case "tokenDoor":
                    TokenDoor cellB = (TokenDoor) cell;
                    String tokens = Integer.toString(cellB.getTokensRequired());
                    label = "m" + tokens;
                    break;
                case "dog":
                    label = "d";
                    break;
                case "prisoner":
                    label = "p";
                    break;
                case "teleport":
                    label = "t";
                    break;
                case "wall":
                    label = "#";
                    break;
                default:
                    label = cell.getCellType().substring(0, 1);
                    array[cell.getxCoord()][cell.getyCoord()] = label;
            }
            array[cell.getxCoord()][cell.getyCoord()] = label;
        }
        return array;
    }

    private String[][] navigatorsToArray(Level level, String[][] array) {
        for (Navigator navigator : level.getNavigators()) {
            String navClass = navigator.getClass().toString().substring(6);
            String label = null;
            switch (navClass) {
                //Cell data underneath player lost.
                case "Player":
                    label = "P";
                    break;
                case "DumbTargetingEnemy":
                    label = "D";
                    break;
                case "SmartEnemy":
                    label = "S";
                    break;
                case "StraightLineEnemy":
                    StraightLineEnemy enemy1 = (StraightLineEnemy) navigator;
                    String direction1 = enemy1.getDirection();
                    label = "L" + direction1.substring(0, 1);
                    break;
                case "WallEnemy":
                    WallEnemy enemy2 = (WallEnemy) navigator;
                    String direction2 = enemy2.getDirection();
                    label = "W" + direction2.substring(0, 1);
                    break;
                default:

            }
            array[navigator.getxCoord()][navigator.getyCoord()] = label;
        }
        return array;
    }

    private void deleteLevelFile(String fileName) {

    }
}
