
/*

 * To change this license header, choose License Headers in Project Properties.

 * To change this template file, choose Tools | Templates

 * and open the template in the editor.
 */

import java.io.File;

import java.io.FileNotFoundException;

import java.util.Scanner;

import javafx.application.Application;

import javafx.event.ActionEvent;

import javafx.event.EventHandler;

import javafx.geometry.Insets;

import javafx.geometry.Pos;

import javafx.scene.Scene;

import javafx.scene.canvas.Canvas;

import javafx.scene.control.Button;

import javafx.scene.control.Label;

import javafx.scene.control.PasswordField;

import javafx.scene.control.TextField;

import javafx.scene.image.Image;

import javafx.scene.image.ImageView;

import javafx.scene.layout.Background;

import javafx.scene.layout.BackgroundImage;

import javafx.scene.layout.BackgroundPosition;

import javafx.scene.layout.BackgroundRepeat;

import javafx.scene.layout.BackgroundSize;

import javafx.scene.layout.GridPane;

import javafx.scene.layout.HBox;

import javafx.scene.layout.Pane;

import javafx.scene.layout.StackPane;

import javafx.scene.paint.Color;

import javafx.scene.text.Font;

import javafx.scene.text.FontWeight;

import javafx.scene.text.Text;

import javafx.stage.Stage;

/**
 *
 *
 *
 * @author ciara
 *
 */
public class LevelSelect extends Application {

    //final String FILENAME = "Leaderboard.txt";
    final StackPane rootPane = new StackPane();
    

  
public static Profile currentPlayer;

    private Canvas canvas;

    int count = 1;

    String name = "empty";

    String score = "empty";

    String name2 = "empty";

    String score2 = "empty";

    String name3 = "empty";

    String score3 = "empty";

    @Override

    public void start(Stage primaryStage) {

        BackgroundImage backgroundImage = new BackgroundImage(new Image("mainmenuwall.png"),
                BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        rootPane.setBackground(new Background(backgroundImage));

//rootPane.setCenter(canvas);
        Label gameTitle = new Label();

        gameTitle.setText("Select Level");

        gameTitle.setStyle(" -fx-text-fill: white; -fx-font-weight: bold");
        gameTitle.setFont(new Font("Copperplate Gothic Bold",60));
        gameTitle.setWrapText(true);

        Image img = new Image("level1.png");

        ImageView imgView = new ImageView(img);
        
        rootPane.getChildren().add(imgView);
        StackPane.setMargin(imgView, new Insets(0, 0, 40, 0));
        StackPane.setMargin(gameTitle, new Insets(0, 0, 390, 0));
        
        Image charaImg = new Image(currentPlayer.getCharacter()+"logo.png");
        ImageView characterView = new ImageView(charaImg);
        
        Image playImg = new Image("picon.png");
        ImageView playView = new ImageView(playImg);
        Image playImg2 = new Image("picon.png");
        ImageView playView2 = new ImageView(playImg2);
        
        Label profileLbl = new Label("UserName - "+currentPlayer.getUserName().toUpperCase()+"\n"+"Current Level - " + currentPlayer.getCurrentLevel(),characterView);
        
        rootPane.getChildren().add(profileLbl);
        StackPane.setMargin(profileLbl, new Insets(0, -730, 445, 0));
        profileLbl.setStyle("-fx-background-color: grey; -fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");

        profileLbl.setMaxWidth(170);

        Button nextBtn = new Button("Next");

        Button prevBtn = new Button("PREV");
        Button homeBtn = new Button("HOME"
                + "");
        Button startBtn = new Button("  START   ",playView);
        Button continueBtn = new Button("CONTINUE",playView2);
        
        rootPane.getChildren().add(gameTitle);

        nextBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");
        homeBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");

        prevBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");

        
        rootPane.getChildren().add(nextBtn);

        StackPane.setMargin(nextBtn, new Insets(0, 0, 0, 400));
        rootPane.getChildren().add(homeBtn);

        StackPane.setMargin(homeBtn, new Insets(-440,830,0,0));
        rootPane.getChildren().add(prevBtn);

        StackPane.setMargin(prevBtn, new Insets(0, 0, 0, -400));

        rootPane.getChildren().add(startBtn);

        StackPane.setMargin(startBtn, new Insets(0, 100, -210, 0));
        rootPane.getChildren().add(continueBtn);

        StackPane.setMargin(continueBtn, new Insets(0, -100, -210, 0));

        prevBtn.setVisible(false);

        

        leaderBoard("LeaderBoard" + count + ".txt");
        
        levelAccess(startBtn,continueBtn,count);
        continueBtn.setVisible(false);
                
        homeBtn.setOnAction(e -> {
            Menu mainMenu = new Menu();
            primaryStage.getScene().setRoot(mainMenu.getRootPane(primaryStage));});
        
        nextBtn.setOnAction(e -> {

            leaderBoard("LeaderBoard" + (count + 1) + ".txt");

            System.out.print("LeaderBoard" + count + ".txt");

            if (count < 7) {

                count = count + 1;
                levelAccess(startBtn,continueBtn,count);

                Image image = new Image("level" + count + ".png");

                System.out.print(("level" + count + ".png"));

                ImageView imageView = new ImageView(image);

                rootPane.getChildren().add(imageView);
                StackPane.setMargin(imageView, new Insets(0, 0, 40, 0));
                
                

            }

            if (count == 7) {

                nextBtn.setVisible(false);

            }

            if (count > 1) {

                prevBtn.setVisible(true);

            }

        });

        prevBtn.setOnAction(e -> {

            leaderBoard("LeaderBoard" + (count - 1) + ".txt");

            if (count < 8) {

                count = count - 1;
                levelAccess(startBtn,continueBtn,count);
                Image image = new Image("level" + count + ".png");

                ImageView imageView = new ImageView(image);
                StackPane.setMargin(imageView, new Insets(0, 0, 40, 0));
                rootPane.getChildren().add(imageView);
                
                

            }

            if (count < 7) {

                nextBtn.setVisible(true);

            }

            if (count < 2) {

                prevBtn.setVisible(false);

            }

        });

        startBtn.setOnAction(e -> {



            //game.currentPlayer = currentPlayer;
            Game level = new Game();
            level.levelSelected = count;
            primaryStage.getScene().setRoot(level.getRootPane(primaryStage));});



//        StackPane root = new StackPane();
//        root.getChildren().add(btn);
//
//        Scene scene = new Scene(root, 300, 250);
//
//        primaryStage.setTitle("Hello World!");
    }

    public void leaderBoard(String FILENAME) {

        File fileName = new File(FILENAME);

        Scanner in = null;

        try {

            in = new Scanner(fileName);

            name = in.nextLine().toUpperCase();

            score = in.nextLine().toUpperCase();

            name2 = in.nextLine().toUpperCase();

            score2 = in.nextLine().toUpperCase();

            name3 = in.nextLine().toUpperCase();

            score3 = in.nextLine().toUpperCase();

            Label leaderHeader = new Label(" RANK                    NAME                        SCORE");

            Image lead1 = new Image("1st.png");

            ImageView leadView = new ImageView(lead1);

            Label leader1 = new Label(("                    " + name + "                       " + score), leadView);

            Image lead2 = new Image("2nd.png");

            ImageView leadView2 = new ImageView(lead2);

            Label leader2 = new Label(("                    " + name2 + "                      " + score2), leadView2);

            Image lead3 = new Image("3rd.png");

            ImageView leadView3 = new ImageView(lead3);

            Label leader3 = new Label(("                    " + name3 + "                        " + score3), leadView3);

            leaderHeader.setStyle("-fx-background-color: black; -fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");

            leader1.setStyle("-fx-background-color: grey; -fx-text-fill: black; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");

            leader2.setStyle("-fx-background-color: grey; -fx-text-fill: black; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");

            leader3.setStyle("-fx-background-color: grey; -fx-text-fill: black; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");

            rootPane.getChildren().add(leaderHeader);

            rootPane.getChildren().add(leader1);

            rootPane.getChildren().add(leader2);

            rootPane.getChildren().add(leader3);

            leaderHeader.setMaxWidth(280);

            leader1.setMaxWidth(280);

            leader2.setMaxWidth(280);

            leader3.setMaxWidth(280);

            StackPane.setMargin(leaderHeader, new Insets(0, 0, -280, 0));

            StackPane.setMargin(leader1, new Insets(0, 0, -330, 0));

            StackPane.setMargin(leader2, new Insets(0, 0, -380, 0));

            StackPane.setMargin(leader3, new Insets(0, 0, -430, 0));

        } catch (FileNotFoundException e) {

            System.out.print("failed");

        }

    }

    public Pane getRootPane(Stage primaryStage) {

        start(primaryStage);

        return rootPane;

    }
    public void levelAccess(Button startBtn,Button continueBtn,int level){
        System.out.println(level+"\n");
        int currentLevel =(currentPlayer.getCurrentLevel())+1;
         if (currentLevel >= level) {

                startBtn.setVisible(true);

                

            }else{
                startBtn.setVisible(false);
            }
         if(currentPlayer.getContinueLevelArray(level)){
                continueBtn.setVisible(true);
            }
         
    }

    /**
     *
     * @param args the command line arguments
     *
     */
    //public static void main(String[] args) {
    //    launch(args);
    //}
}
