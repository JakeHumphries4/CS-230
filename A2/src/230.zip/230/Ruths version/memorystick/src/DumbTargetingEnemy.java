public class DumbTargetingEnemy extends Navigator {

    public DumbTargetingEnemy(Cell cell) {
        super(cell);
    }

    public void move(int playerX, int playerY) {
        if (getxCoord() > playerX && (Math.abs(getxCoord() - playerX) > Math.abs(getyCoord() - playerY)) && getCell().getWest().getCellType().equals("ground")) {
            moveWest();
        } else if (getxCoord() < playerX && (Math.abs(getxCoord() - playerX) > Math.abs(getyCoord() - playerY)) && getCell().getEast().getCellType().equals("ground")) {
            moveEast();
        } else if (getyCoord() > playerY && (Math.abs(getyCoord() - playerY) > Math.abs(getxCoord() - playerX)) && getCell().getNorth().getCellType().equals("ground")) {
            moveNorth();
        } else if (getyCoord() < playerY && (Math.abs(getyCoord() - playerY) > Math.abs(getxCoord() - playerX)) && getCell().getSouth().getCellType().equals("ground")) {
            moveSouth();
        }
    }
}
