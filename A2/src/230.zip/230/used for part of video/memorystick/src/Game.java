import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.util.ArrayList;
import javafx.geometry.Insets;
import javafx.scene.control.Button;

/**
 * The class that handles most of the user interface.
 * @author
 * @version 5.7
 */
public class Game extends Application {

    private final StackPane holder = new StackPane();
    //level selected by user to play in LevelSelect
    public static int levelSelected;
    // The dimensions of the window
    private static final int WINDOW_WIDTH = 900;
    private static final int WINDOW_HEIGHT = 500;
    public static Profile currentPlayer;
    // The dimensions of the canvas
    private static final int CANVAS_WIDTH = 900;
    private static final int CANVAS_HEIGHT = 500;
    // The size of each cell on the canvas.
    private static final int CELL_SIZE = 100;

    // Amount to shift the cells by when setting up the level.
    private int cellShiftX;
    private int cellShiftY;
    // Used in timer for leaderboard scores.
    private long lastNanoTime;
    private Sprite playerSprite;
    private Player player;
    private Level currLevel;
    //Indicates if the player has moved on this turn.
    private boolean hasMove = false;
    //The walls surrounding the navigatable part of the cell.
    private BackgroundImage myBI = new BackgroundImage(new Image("Cells/wall.png", CELL_SIZE,
            CELL_SIZE, false, true), BackgroundRepeat.REPEAT,
            BackgroundRepeat.REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

    //Various arrays that hold data needed in thel level.
    private ArrayList<Cell> cellList = new ArrayList<Cell>();
    private ArrayList<Navigator> navigatorList = new ArrayList<Navigator>();
    private ArrayList<Sprite> cellSpriteList = new ArrayList<Sprite>();
    private ArrayList<Sprite> navSpriteList = new ArrayList<Sprite>();
    private ArrayList<Sprite> allSpriteList = new ArrayList<Sprite>();
    private ArrayList<Sprite> invSpriteList = new ArrayList<Sprite>();
    private ArrayList<Sprite> tokenSpriteList = new ArrayList<Sprite>();

    /**
     * Assigns a sprite for each type of object. and sets the north, east, south and west of each cell.
     */
    private void initCells() {
        for (Cell cell : cellList) {
            String cellType = cell.getCellType();
            switch (cellType) {
                case "wall":
                    Sprite wallSprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/wall.png"), "wall");
                    cellSpriteList.add(wallSprite);
                    break;
                case "ground":
                    Sprite groundSprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/ground.png"), "ground");
                    cellSpriteList.add(groundSprite);
                    break;
                case "keyDoor1":
                    Sprite keyDoor1Sprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/breakableglass.png"),"keyDoor1");
                    cellSpriteList.add(keyDoor1Sprite);
                    break;
                case "keyDoor2":
                    Sprite keyDoor2Sprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/breakablewall.png"),"keyDoor1");
                    cellSpriteList.add(keyDoor2Sprite);
                    break;
                case "keyDoor3":
                    Sprite keyDoor3Sprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/breakablewire.png"),"keyDoor1");
                    cellSpriteList.add(keyDoor3Sprite);
                    break;
                case "tokenDoor1":
                    Sprite tokenDoor1Sprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/tokendoor1.png"),"tokenDoor1");
                    cellSpriteList.add(tokenDoor1Sprite);
                    break;
                case "tokenDoor2":
                    Sprite tokenDoor2Sprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/tokendoor2.png"),"tokenDoor2");
                    cellSpriteList.add(tokenDoor2Sprite);
                    break;
                case "tokenDoor3":
                    Sprite tokenDoor3Sprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/tokendoor3.png"),"tokenDoor3");
                    cellSpriteList.add(tokenDoor3Sprite);
                    break;
                case "tokenDoor4":
                    Sprite tokenDoor4Sprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/tokendoor4.png"),"tokenDoor4");
                    cellSpriteList.add(tokenDoor4Sprite);
                    break;

                case "teleport":
                    Sprite teleportSprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/teleporthole.png"), "teleport");
                    cellSpriteList.add(teleportSprite);
                    break;
                case "goal":
                    Sprite goalSprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/goal.png"), "goal");
                    cellSpriteList.add(goalSprite);
                    break;
                case "dog":
                    Sprite dogSprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/dog.png"), "dog");
                    cellSpriteList.add(dogSprite);
                    break;
                case "prisoner":
                    Sprite prisonerSprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/prisoner.png"), "prisoner");
                    cellSpriteList.add(prisonerSprite);
                    break;
                case "token":
                    Sprite moneySprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/passcodetoken.png"), "token");
                    cellSpriteList.add(moneySprite);
                    break;
                case "1":
                    Sprite key1Sprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/hammer.png"), "1");
                    cellSpriteList.add(key1Sprite);
                    break;
                case "2":
                    Sprite key2Sprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/bomb.png"), "2");
                    cellSpriteList.add(key2Sprite);
                    break;
                case "3":
                    Sprite key3Sprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/wirecutter.png"), "3");
                    cellSpriteList.add(key3Sprite);
                    break;
                case "bone":
                    Sprite boneSprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/bone.png"), "bone");
                    cellSpriteList.add(boneSprite);
                    break;
                case "cigs":
                    Sprite cigSprite = new Sprite(cell.getxCoord() * CELL_SIZE, cell.getyCoord() * CELL_SIZE,
                            new Image("Cells/cigs.png"), "cigs");
                    cellSpriteList.add(cigSprite);
                    break;
                default:
                    System.out.println(cell.getCellType());
                    System.out.println("Oh no");
            }

        }
        allSpriteList.addAll(cellSpriteList);
        int levelX = currLevel.getxDimensions();
        for (int i = 0; i < cellList.size(); i++) {
            Cell currentCell = cellList.get(i);
            if (i >= levelX) {
                currentCell.setNorth(cellList.get(i - levelX));
            }
            if ((i % levelX) < levelX - 1) {
                currentCell.setEast(cellList.get(i + 1));
            }
            if (i < cellList.size() - levelX) {
                currentCell.setSouth(cellList.get(i + levelX));
            }
            if ((i % levelX) > 0) {
                currentCell.setWest(cellList.get(i - 1));
            }
        }
    }

    /**
     * Sets the sprites for all the enemies and the player.
     */
    private void initNav() {
        for (Navigator nav : navigatorList) {
            String navType = (nav.getClass().toString().substring(6));
            switch (navType) {
                case "Player":
                    Sprite playerNav = new Sprite(nav.getxCoord() * CELL_SIZE, nav.getyCoord() * CELL_SIZE,
                            new Image(currentPlayer.getCharacter()+".png"), "player");
                    allSpriteList.add(playerNav);
                    playerSprite = playerNav;
                    player = (Player) nav;
                    player.setLevel(currLevel);
                    break;
                case "SmartEnemy":
                    Sprite smartNav = new Sprite(nav.getxCoord() * CELL_SIZE, nav.getyCoord() * CELL_SIZE,
                            new Image("Cells/guard.png"), "smart");
                    navSpriteList.add(smartNav);
                    allSpriteList.add(smartNav);
                    break;
                case "DumbTargetingEnemy":
                    Sprite lineNav = new Sprite(nav.getxCoord() * CELL_SIZE, nav.getyCoord() * CELL_SIZE,
                            new Image("Cells/guard.png"), "line");
                    navSpriteList.add(lineNav);
                    allSpriteList.add(lineNav);
                    break;
                case "StraightLineEnemy":
                    Sprite dumbNav = new Sprite(nav.getxCoord() * CELL_SIZE, nav.getyCoord() * CELL_SIZE,
                            new Image("Cells/guard.png"), "dumb");
                    navSpriteList.add(dumbNav);
                    allSpriteList.add(dumbNav);
                    break;
                case "WallEnemy":
                    Sprite wallNav = new Sprite(nav.getxCoord() * CELL_SIZE, nav.getyCoord() * CELL_SIZE,
                            new Image("Cells/guard.png"), "wall");
                    navSpriteList.add(wallNav);
                    allSpriteList.add(wallNav);
                    break;
            }
        }
    }

    /**
     * Loads in the level from a file and copies over all the cells and navigators from it.
     * @param levelNum The level that the user has loaded.
     */
    private void initLevel(int levelNum) {
        currLevel = new LevelController().loadLevel(String.format("src/Level_Files/Level%s.txt", levelNum));
        cellList.addAll(currLevel.getCells());
        navigatorList.addAll(currLevel.getNavigators());
        initCells();
        initNav();
    }

    /**
     * Centers the view on the player.
     */
    private void viewShift() {
        int playerX = player.getxCoord();
        int playerY = player.getyCoord();
        double doubleShiftX = Math.ceil((CANVAS_WIDTH / CELL_SIZE) / 2.0) - 1 - playerX;
        cellShiftX = (int) doubleShiftX * CELL_SIZE;
        double doubleShiftY = Math.ceil((CANVAS_HEIGHT / CELL_SIZE) / 2.0) - 1 - playerY;
        cellShiftY = (int) doubleShiftY * CELL_SIZE;

        for (Sprite sprite : allSpriteList) {
            sprite.move("north", cellShiftY);
            sprite.move("west", cellShiftX);
            //System.out.println(sprite.toString());
        }
    }

    /**
     * Shows how many tokens the user has collected in the level.
     */
    private void displayToken(){
        int tokenCount = player.getTokens();
        Image tokenImage = new Image("Cells/token.png",25,16,true,true);
        if (tokenCount == 0) {
            tokenSpriteList.clear();
        }
        else if (tokenCount >=1) {
            tokenSpriteList.clear();
            for(int i=tokenCount-1;i>=0;i--) {
                Sprite tokenSprite = new Sprite(870, 2 + (i * 18), tokenImage, "inv");
                tokenSpriteList.add(tokenSprite);
            }
        }
    }

    /**
     * Shows all the items that the player has picked up in the level.
     */
    private void displayInv() {
        ArrayList<String> inv = player.getInventory();
        for (String item : inv) {
            switch (item) {
                case "token":
                    displayToken();
                    break;
                case "3":
                    Image wirecutterImage = new Image("Cells/wirecutterInv.png", 24, 29, true, true);
                    Sprite wirecutterSprite = new Sprite(815, 10, wirecutterImage, "inv");
                    invSpriteList.add(wirecutterSprite);
                    break;
                case "2":
                    Image bombImage = new Image("Cells/bombInv.png");
                    Sprite bombSprite = new Sprite(785, 5, bombImage, "inv");
                    invSpriteList.add(bombSprite);
                    break;
                case "1":
                    Image hammerImage = new Image("Cells/hammerInv.png", 30, 30, true, true);
                    Sprite hammerSprite = new Sprite(745, 6, hammerImage, "inv");
                    invSpriteList.add(hammerSprite);
                    break;
                case "cigs":
                    Image cigsImage = new Image("Cells/cigsInv.png", 15, 33, true, true);
                    Sprite cigsSprite = new Sprite(720, 2, cigsImage, "inv");
                    invSpriteList.add(cigsSprite);
                    break;
                case "bone":
                    Image boneImage = new Image("Cells/boneInv.png", 32, 20, true, true);
                    Sprite boneSprite = new Sprite(670, 10, boneImage, "inv");
                    invSpriteList.add(boneSprite);
                    break;

            }
        }

    }

    //Updates all the sprite positions after they have all made their movements.
    private void moveSprites(ArrayList<String> input) {
        if (!hasMove && input.size() != 0) {
            //If the user has moved, everything else moves as well. This variable keeps track of if they move or not.
            boolean moveSprites = false;
            if (input.contains("LEFT")) {
                moveSprites = player.move("LEFT");
            } else if (input.contains("RIGHT")) {
                moveSprites = player.move("RIGHT");
            } else if (input.contains("UP")) {
                moveSprites = player.move("UP");
            } else if (input.contains("DOWN")) {
                moveSprites = player.move("DOWN");
            }
            if (moveSprites) {
                for (Navigator nav : navigatorList) {
                    if (nav.getClass().toString().substring(6).equals("StraightLineEnemy")) {
                        StraightLineEnemy sLENav = (StraightLineEnemy) nav;
                        String shiftDirection = sLENav.move();
                        //-1 because the player is not in the sprite list but is in the navigator list.
                        navSpriteList.get(navigatorList.indexOf(nav)-1).move(shiftDirection, CELL_SIZE);
                    } else if (nav.getClass().toString().substring(6).equals("DumbTargetingEnemy")) {
                        DumbTargetingEnemy dTENav = (DumbTargetingEnemy) nav;
                        String shiftDirection = dTENav.move(player.getxCoord(), player.getyCoord());
                        //-1 because the player is not in the sprite list but is in the navigator list.
                        if (shiftDirection != null) {
                            navSpriteList.get(navigatorList.indexOf(nav) - 1).move(shiftDirection, CELL_SIZE);
                        }
                    }  else if (nav.getClass().toString().substring(6).equals("WallEnemy")) {
                        WallEnemy wENav = (WallEnemy) nav;
                        String shiftDirection = wENav.move();
                        //-1 because the player is not in the sprite list but is in the navigator list.
                        if (shiftDirection != null) {
                            navSpriteList.get(navigatorList.indexOf(nav) - 1).move(shiftDirection, CELL_SIZE);
                        }
                    } else if (nav.getClass().toString().substring(6).equals("SmartEnemy")) {

                        SmartEnemy sENav = (SmartEnemy) nav;
                        String shiftDirection = sENav.move(player.getxCoord(), player.getyCoord());
                        //-1 because the player is not in the sprite list but is in the navigator list.
                        if (shiftDirection != null) {
                            navSpriteList.get(navigatorList.indexOf(nav) - 1).move(shiftDirection, CELL_SIZE);
                        }
                    }
                }
                for (Sprite sprite : allSpriteList) {
                    if (!sprite.getType().equals("player")) {
                        if (input.contains("LEFT")) {
                            sprite.move("west", CELL_SIZE);
                            hasMove = true;
                        } else if (input.contains("RIGHT")) {
                            sprite.move("east", CELL_SIZE);
                            hasMove = true;
                        } else if (input.contains("UP")) {
                            sprite.move("north", CELL_SIZE);
                            hasMove = true;
                        } else if (input.contains("DOWN")) {
                            sprite.move("south", CELL_SIZE);
                            hasMove = true;
                        }
                    }
                }
                checkCell(input);

            }
        }
        //If the input is empty, the user doesn't have a button pressed, and so no-one should move.
        if (input.size() == 0) {
            hasMove = false;
        }
    }

    /**
     * Checks any special cells that the player may move onto.
     * @param input The buttons that the user has pressed at the time.
     */
    private void checkCell(ArrayList<String> input) {
        Cell currCell = player.getCell();
        String type = currCell.getCellType();
        switch (type){
            case "keyDoor1":
                makeCellToGround(currCell);
                break;
            case "keyDoor2":
                makeCellToGround(currCell);
                break;
            case "keyDoor3":
                makeCellToGround(currCell);
                break;
            case "tokenDoor1":
                if (player.getTokens() >= 1) {
                    makeCellToGround(currCell);
                    player.subTokens(1);
                }
                break;
            case "tokenDoor2":
                if (player.getTokens() >= 2) {
                    makeCellToGround(currCell);
                    player.subTokens(2);
                }
                break;
            case "tokenDoor3":
                if (player.getTokens() >= 3) {
                    makeCellToGround(currCell);
                    player.subTokens(3);
                }
                break;
            case "tokenDoor4":
                if (player.getTokens() >= 4) {
                    makeCellToGround(currCell);
                    player.subTokens(4);
                }
                break;

            case "teleport":
                teleportPlayer();
                moveSprites(input);
                break;
            case "goal":
                player.setReachedGoal(System.nanoTime());
                System.out.println(player.timePlayedToString());
                break;
            case "token":
                player.addToken();
                player.addInventory("token");
                makeCellToGround(currCell);
                break;
            case "3":
                player.addInventory("3");
                makeCellToGround(currCell);
                break;
            case "2":
                player.addInventory("2");
                makeCellToGround(currCell);
                break;
            case "1":
                player.addInventory("1");
                makeCellToGround(currCell);
                break;
            case "cigs":
                player.addInventory("cigs");
                makeCellToGround(currCell);
                break;
            case "bone":
                player.addInventory("bone");
                makeCellToGround(currCell);
                break;

        }
    }

    /**
     * Converts a cell into a ground tile.
     * @param cell The cell that is being converted.
     * @param newXCoord The new x coordinate of the cell.
     * @param newYCoord The new y coordinate of the cell.
     */
    private void makeCellToGround(Cell cell,int newXCoord, int newYCoord){
        cell.setCellType("ground");
        int cellX = cell.getxCoord();
        int cellY = cell.getyCoord();
        int levelX = currLevel.getxDimensions();
        int index = (cellY*levelX)+cellX;

        cellSpriteList.set(index,new Sprite(newXCoord, newYCoord,
                new Image("Cells/ground.png"), "ground"));
        allSpriteList.set(index,new Sprite(newXCoord, newYCoord,
                new Image("Cells/ground.png"), "ground"));
    }

    /**
     * Converts a cell into a ground tile.
     * @param cell The cell that is being converted.
     */
    private void makeCellToGround(Cell cell) {
        cell.setCellType("ground");
        int cellX = cell.getxCoord();
        int cellY = cell.getyCoord();
        int levelX = currLevel.getxDimensions();
        int index = (cellY * levelX) + cellX;
        int newXCoord = (int) playerSprite.getPositionX();
        int newYCoord = (int) playerSprite.getPositionY();

        cellSpriteList.set(index, new Sprite(newXCoord, newYCoord,
                new Image("Cells/ground.png"), "ground"));
        allSpriteList.set(index, new Sprite(newXCoord, newYCoord,
                new Image("Cells/ground.png"), "ground"));
    }

    /**
     * Teleports a from one side of a teleporter to the other side of it's pair.
     */
    private void teleportPlayer() {
        Cell currCell = player.getCell();
        Cell pairCell = ((Teleport) currCell).getPair();
        cellShiftX = (int) (currCell.getxCoord() - pairCell.getxCoord()) * CELL_SIZE;
        cellShiftY = (int) (currCell.getyCoord() - pairCell.getyCoord()) * CELL_SIZE;
        player.setCell(pairCell);
        for (Sprite sprite : allSpriteList) {
            if (sprite != playerSprite) {
                sprite.addPositionY(cellShiftY);
                sprite.addPositionX(cellShiftX);
            }
        }
    }

    /**
     * Launches the program.
     * @param args Any arguments passed to the program.
     */
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * Builds the window that the program starts in and decorates it.
     * @param theStage The window to put the content in.
     */
    public void start(Stage theStage) {
        theStage.setTitle("Llama Prison Drama!");

        Canvas canvas = new Canvas(CANVAS_WIDTH, CANVAS_HEIGHT);
        Group root = new Group();

        StackPane holder = new StackPane();
        holder.setBackground(new Background(myBI));
        holder.getChildren().add(canvas);

        root.getChildren().add(holder);
        Scene mainScene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);
        theStage.setScene(mainScene);
        GraphicsContext gc = canvas.getGraphicsContext2D();
Button back = new Button();
        back.setText("BACK");
        root.getChildren().add(back);
        
        StackPane.setMargin(back, new Insets(-440,830,0,0));
        initLevel(levelSelected);
        viewShift();

        ArrayList<String> input = new ArrayList<String>();
        back.setOnAction(e -> {
            LevelSelect levelSelect = new LevelSelect();
            theStage.getScene().setRoot(levelSelect.getRootPane(theStage));});
        mainScene.setOnKeyPressed(event -> {
            String code = event.getCode().toString();

            if (!input.contains(code))
                input.add(code);
        });
        mainScene.setOnKeyReleased(event -> {
            String code = event.getCode().toString();
            input.remove(code);
        });

        lastNanoTime = System.nanoTime();
        player.setStartTime();
        AnimationTimer mainLoop = new AnimationTimer() {
            @Override
            public void handle(long currentNanoTime) {
                lastNanoTime = currentNanoTime;
                displayInv();
                moveSprites(input);
                gc.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
                for (Sprite sprite : allSpriteList) {
                    sprite.render(gc);
                }
                for (Sprite sprite : invSpriteList) {
                    sprite.render(gc);
                }
                for (Sprite sprite : tokenSpriteList) {
                    sprite.render(gc);
                }
                //If there is a collision between an enemy and the player, the player dies.
                for (Sprite nav : navSpriteList) {
                    if (playerSprite.intersects(nav)) {
                        player.die();

                    }
                    //If the player dies, clear all the data about the level and re-initialise it.
                    if (player.getDead()) {
                        cellList.clear();
                        cellSpriteList.clear();
                        navigatorList.clear();
                        navSpriteList.clear();
                        allSpriteList.clear();
                        tokenSpriteList.clear();

                        initCells();
                        initNav();
                        initLevel(currLevel.getNumber());
                        viewShift();
                    }

                    //Alternative below:
                    /*
                    if (player.getDead()) {
                        System.out.println("player is DEAD!!!");
                        LevelSelect levelSelect = new LevelSelect();
                        holder.getScene().setRoot(levelSelect.getRootPane(theStage));
                        //initLevel(currLevel.getNumber());
                        //viewShift();
                    }
                    */
                }

            }
        };
        mainLoop.start();
        theStage.show();
    }

    public Pane getRootPane(Stage primaryStage) {
        start(primaryStage);
        return holder;
    }
}