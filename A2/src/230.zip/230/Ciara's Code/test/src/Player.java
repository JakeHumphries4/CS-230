
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ciara
 */
public class Player extends Movable{
    
    ArrayList<Collectable> inventory = new ArrayList<Collectable>();
    Collectable Token = new Collectable();
    Boolean goal= false;
    Boolean dead = false;
    
    public Player (Profile profile) {
        super();
        Token = 0;
        
    }
    public ArrayList<Collectable> getInventory() {
        return inventory;
    }

    public void setInventory(ArrayList<Collectable> inventory) {
        this.inventory = inventory;
    }

    public Boolean getGoal() {
        return goal;
    }

    private void setGoal() {
        this.goal = true;
    }

    public Boolean getDead() {
        return dead;
    }

    private void setDead() {
        this.dead = true;
    }
    private void pickUpItem(Cell cell){
        if (cell instanceof Collectable){
            ArrayList invent = getInventory();
            Collectables.addToken();
        }
        if (cell instanceof Collectable ){
            if (cell.getType = "Dog key" ){
                Collectables.addDogKey();
            }
            if (cell.getType = "Guard Key" ){
                Collectables.addGuardKey();
            } 
        }
    }
    private void useItem(Cell cell){
        if (cell instanceof TokenDoor){
            ArrayList invent = getInventory();
            Collectables.takeTokens();
        }
        if (cell instanceof ColoredDoor ){
            if (cell.getType = "Dog key" ){
                Collectables.takeDogKey();
            }
            if (cell.getType = "Guard Key" ){
                Collectables.takeGuardKey();
            } 
        }
    }
    private void move(){
        
    }
    private void completeLevel(){
        Level level = Level.getNextLevel();
       
        Player.setCurrentLevel(Level level);
        MainMeun();
    }
    private void checkCellType(Cell cell){
        String type ;
        if (cell.getType = "Item" ){
            pickUpItem(cell);
        }
        if (cell instanceof KillCell ){
            setDead();
            death();
           
        }
        if (cell instanceof GoalCell ){
            setGoal();
            completeLevel();
            
        }
         
    }
    private void death(){
        Level level = Level.getCurrentLevel();
        MainMeun();
    }

}
