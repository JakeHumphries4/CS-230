import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * This class allows for a user to chose which level they want to play
 * @author Ciara Freegard
 * @version 2.0
 */
	public class LevelSelect extends Application {

    //final String FILENAME = "Leaderboard.txt";
    final StackPane rootPane = new StackPane();
    
    /**
     * Shows which profile is currently playing
     */
    public static Profile currentPlayer;

    	private Canvas canvas;

    	int count = 1;
    	int currentLevel;

    	String name = "empty";

    	String score = "empty";

    	String name2 = "empty";

    	String score2 = "empty";
    	
    	String name3 = "empty";

    	String score3 = "empty";

    @Override

    /**
     * This method starts the Javafx for this menu, by displaying all the necessary buttons needed
     * to select which level a user wants to play
     * @param primaryStage - The main window
     */
    public void start(Stage primaryStage) {

        BackgroundImage backgroundImage = new BackgroundImage(new Image("mainmenuwall.png"),
                BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        rootPane.setBackground(new Background(backgroundImage));

//rootPane.setCenter(canvas);
        Label gameTitle = new Label();
        currentPlayer.setContinueLevelArray(2, Boolean.TRUE);
        gameTitle.setText("Select Level");

        gameTitle.setStyle(" -fx-text-fill: white; -fx-font-weight: bold");
        gameTitle.setFont(new Font("Copperplate Gothic Bold",60));
        gameTitle.setWrapText(true);

        Image img = new Image("level1.png");

        ImageView imgView = new ImageView(img);
        
        rootPane.getChildren().add(imgView);
        StackPane.setMargin(imgView, new Insets(0, 0, 40, 0));
        StackPane.setMargin(gameTitle, new Insets(0, 0, 390, 0));
        
        Image charaImg = new Image(currentPlayer.getCharacter()+"logo.png");
        ImageView characterView = new ImageView(charaImg);
        
        Image playImg = new Image("picon.png");
        ImageView playView = new ImageView(playImg);
        Image playImg2 = new Image("picon.png");
        ImageView playView2 = new ImageView(playImg2);
        
        Label profileLbl = new Label("UserName - "+currentPlayer.getUserName().toUpperCase()+"\n"+"Current Level - " + currentPlayer.getCurrentLevel(),characterView);
        
        rootPane.getChildren().add(profileLbl);
        StackPane.setMargin(profileLbl, new Insets(0, -730, 445, 0));
        profileLbl.setStyle("-fx-background-color: grey; -fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");

        profileLbl.setMaxWidth(170);

        Button nextBtn = new Button("NEXT");

        Button prevBtn = new Button("PREV");
        Button homeBtn = new Button("HOME"
                + "");
        Button startBtn = new Button("  START   ",playView);
        Button continueBtn = new Button("CONTINUE",playView2);
        
        rootPane.getChildren().add(gameTitle);
        startBtn.setStyle("-fx-font-size: 9px;");
        continueBtn.setStyle("-fx-font-size: 9px;");
        nextBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");
        homeBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");

        prevBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");

        
        rootPane.getChildren().add(nextBtn);

        StackPane.setMargin(nextBtn, new Insets(0, 0, 0, 400));
        rootPane.getChildren().add(homeBtn);

        StackPane.setMargin(homeBtn, new Insets(-440,830,0,0));
        rootPane.getChildren().add(prevBtn);

        StackPane.setMargin(prevBtn, new Insets(0, 0, 0, -400));

        rootPane.getChildren().add(startBtn);

        StackPane.setMargin(startBtn, new Insets(0, 100, -210, 0));
        rootPane.getChildren().add(continueBtn);

        StackPane.setMargin(continueBtn, new Insets(0, -100, -210, 0));

        prevBtn.setVisible(false);

        

        leaderBoard("LeaderBoard" + count + ".txt");
        
        levelAccess(startBtn,continueBtn,count);
        continueBtn.setVisible(false);
                
        /**
         * This button returns the user back to the main menu
         */
        homeBtn.setOnAction(e -> {
            Menu mainMenu = new Menu();
            primaryStage.getScene().setRoot(mainMenu.getRootPane(primaryStage));});
        
        /**
         * This button allows the user to view the next level
         */
        nextBtn.setOnAction(e -> {

            leaderBoard("LeaderBoard" + (count + 1) + ".txt");

            System.out.print("LeaderBoard" + count + ".txt");

            if (count < 7) {

                count = count + 1;
                levelAccess(startBtn,continueBtn,count);

                Image image = new Image("level" + count + ".png");

                System.out.print(("level" + count + ".png"));

                ImageView imageView = new ImageView(image);

                rootPane.getChildren().add(imageView);
                StackPane.setMargin(imageView, new Insets(0, 0, 40, 0));
                if(!currentPlayer.getContinueLevelArray(count)){
                    continueBtn.setVisible(false);
                }
            }

            if (count == 7) {

                nextBtn.setVisible(false);

            }if (count > 1) {

                prevBtn.setVisible(true);

            }

        });

        /**
         * This button allows the user to view the previous level
         */
        prevBtn.setOnAction(e -> {

            leaderBoard("LeaderBoard" + (count - 1) + ".txt");

            if (count < 8) {

                count = count - 1;
                levelAccess(startBtn,continueBtn,count);
                Image image = new Image("level" + count + ".png");

                ImageView imageView = new ImageView(image);
                StackPane.setMargin(imageView, new Insets(0, 0, 40, 0));
                rootPane.getChildren().add(imageView);
                if(!currentPlayer.getContinueLevelArray(count)){
                    continueBtn.setVisible(false);
                }
                
            }
            if (count < 7) {
                nextBtn.setVisible(true);
            }
            if (count < 2) {
                prevBtn.setVisible(false);

            }
        });

        startBtn.setOnAction(e -> {
            
        });

    }

    /**
     * This method allows the leader boards for each level to 
     * be displayed
     * @param FILENAME - The file that contains the leader boards for a level
     */
    public void leaderBoard(String FILENAME) {

        File fileName = new File(FILENAME);

        Scanner in = null;

        try {

            in = new Scanner(fileName);

            name = in.nextLine().toUpperCase();

            score = in.nextLine().toUpperCase();

            name2 = in.nextLine().toUpperCase();

            score2 = in.nextLine().toUpperCase();

            name3 = in.nextLine().toUpperCase();

            score3 = in.nextLine().toUpperCase();

            Label leaderHeader = new Label(" RANK                    NAME                        SCORE");

            Image lead1 = new Image("1st.png");

            ImageView leadView = new ImageView(lead1);

            

            Image lead2 = new Image("2nd.png");

            ImageView leadView2 = new ImageView(lead2);

              Image lead3 = new Image("3rd.png");

            ImageView leadView3 = new ImageView(lead3);

             Label leader1 = new Label("                    " + name, leadView);
            Label leader1score = new Label("       "+ score);

            Label leader2 = new Label("                    " + name2, leadView2);
            Label leader2score = new Label ("       "+ score2);

            Label leader3 = new Label("                    " + name3 , leadView3);
            Label leader3score = new Label("       "+ score3);
            
            
            leaderHeader.setStyle("-fx-background-color: black; -fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");
            leader1.setStyle("-fx-background-color: grey; -fx-text-fill: black; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");
            leader2.setStyle("-fx-background-color: grey; -fx-text-fill: black; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");
            leader3.setStyle("-fx-background-color: grey; -fx-text-fill: black; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0;");
            leader1score.setStyle("-fx-background-color: grey; -fx-text-fill: black; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 0 0 0 0; -fx-background-insets: 0;");
            leader2score.setStyle("-fx-background-color: grey; -fx-text-fill: black; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 0 0 0 0; -fx-background-insets: 0;");
            leader3score.setStyle("-fx-background-color: grey; -fx-text-fill: black; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 0 0 0 0; -fx-background-insets: 0;");

            rootPane.getChildren().add(leaderHeader);
            rootPane.getChildren().add(leader1);
            rootPane.getChildren().add(leader2);
            rootPane.getChildren().add(leader3);
            rootPane.getChildren().add(leader1score);
            rootPane.getChildren().add(leader2score);
            rootPane.getChildren().add(leader3score);

            leaderHeader.setMaxWidth(280);

            leader1.setMaxWidth(280);

            leader2.setMaxWidth(280);

            leader3.setMaxWidth(280);
            leader1score.setMaxWidth(100);
            leader2score.setMaxWidth(100);
            leader3score.setMaxWidth(100);

            StackPane.setMargin(leaderHeader, new Insets(0, 0, -280, 0));

            StackPane.setMargin(leader1, new Insets(0, 0, -330, 0));

            StackPane.setMargin(leader2, new Insets(0, 0, -380, 0));

            StackPane.setMargin(leader3, new Insets(0, 0, -430, 0));
            StackPane.setMargin(leader1score, new Insets(0, 0, -330, 150));
            StackPane.setMargin(leader2score, new Insets(0, 0, -380, 150));
            StackPane.setMargin(leader3score, new Insets(0, 0, -430, 150));
        } catch (FileNotFoundException e) {

            System.out.print("failed");

        }

    }

    /**
     * This method gets the root pane
     * @param primaryStage - The main window
     * @return The root pane
     */
    public Pane getRootPane(Stage primaryStage) {

        start(primaryStage);

        return rootPane;

    }
    
    /**
     * This methods checks whether a level can be currently accessed by a
     * user, by checking if they have completed the previous level.
     * @param startBtn - The button that begins a level
     * @param continueBtn - The button that continues a level if the player 
     * had saved the level and left.
     * @param level - The level that is being accessed
     */
    public void levelAccess(Button startBtn,Button continueBtn,int level){
        System.out.println(level+"\n");
        int currentLevel =(currentPlayer.getCurrentLevel())+1;
         if (currentLevel >= level) {

                startBtn.setVisible(true);

                

            }else{
                startBtn.setVisible(false);
            }
         if(currentPlayer.getContinueLevelArray(level)){
                continueBtn.setVisible(true);
            }
    }
}