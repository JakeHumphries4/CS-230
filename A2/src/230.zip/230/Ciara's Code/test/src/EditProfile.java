
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;

/**
 * This class represents the java fx of the window of picking an existing
 * profile.
 *
 * @author Ciara Freegard
 * @version 1.2
 */
public class EditProfile extends Application {

    final StackPane rootPane = new StackPane();
    final String FILENAME = "Player.txt";
    Boolean uFound = false;
    public String check;

    private String name1 = "EMPTY";
    private String currentLevel1 = "N/A";
    private String character1 = "llama";
    private String name2 = "EMPTY";
    private String currentLevel2 = "N/A";
    private String character2 = "llama";
    private String name3 = "EMPTY";
    private String currentLevel3 = "N/A";
    private String character3 = "llama";
    private String name4 = "EMPTY";
    private String currentLevel4 = "N/A";
    private String character4 = "llama";
    private String name5 = "EMPTY";
    private String currentLevel5 = "N/A";
    private String character5 = "llama";

    private String currentName = "";
    private String currentLevel = "";
    private String currentCharacter = "";

    /**
     * Main method to launch the class.
     */
    public static void main(String[] args) {
        launch(args);

    }

    @Override
    /**
     * Creates the edit profile page using a stackpane .
     *
     * @param primarystage the main window.
     */
    public void start(Stage primaryStage) {

        fileReader();
        Label gameTitle = new Label("Edit Existing Player");
        Label errorLbl = new Label();
        Label label3 = new Label();
        Label label2 = new Label();
        /*
         * Generates the buttons for the profiles.
         */

        TextField newNameFld = new TextField();
        Button profile1 = new Button("                  Profile 1: " + name1 + "\n                  Current level : " + currentLevel1);
        Button profile2 = new Button("                  Profile 2: " + name2 + "\n                  Current level : " + currentLevel2);
        Button profile3 = new Button("                  Profile 3: " + name3 + "\n                  Current level : " + currentLevel);
        Button profile4 = new Button("                  Profile 4: " + name4 + "\n                  Current level : " + currentLevel4);
        profile4.setWrapText(true);
        Button profile5 = new Button("                  Profile 5: " + name5 + "\n                  Current level : " + currentLevel5);

        Button back = new Button("BACK");
        Button confirmBtn = new Button("CONFIRM");
        Button editProfile = new Button(" EDIT PROFILE ");
        Button deleteProfile = new Button("DELETE PROFILE");

        /*
         * Generates the images for the profiles.
         */
        Image imge = new Image(character1 + "logo.png");
        profile1.setGraphic(new ImageView(imge));
        Image imge2 = new Image(character2 + "logo.png");
        profile2.setGraphic(new ImageView(imge2));
        Image imge3 = new Image(character3 + "logo.png");
        profile3.setGraphic(new ImageView(imge3));
        Image imge4 = new Image(character4 + "logo.png");
        profile4.setGraphic(new ImageView(imge4));
        Image imge5 = new Image(character5 + "logo.png");
        profile5.setGraphic(new ImageView(imge5));

        /*
         * Setting the styles of all the buttons.
         */
        gameTitle.setStyle("-fx-text-fill: white; -fx-font-weight: bold;");
        gameTitle.setFont(new Font("Copperplate Gothic Bold", 60));
        errorLbl.setStyle("-fx-text-fill: white; -fx-font-weight: bold;");
        label3.setStyle("-fx-text-fill: white; -fx-font-size: 15px; -fx-font-weight: bold;");
        profile1.setStyle("-fx-border-color:green;-fx-pref-height: 8px; -fx-pref-width: 300px;");
        profile2.setStyle("-fx-border-color:green;-fx-pref-height: 8px; -fx-pref-width: 300px;");
        profile3.setStyle("-fx-border-color:green;-fx-pref-height: 8px; -fx-pref-width: 300px;");
        profile4.setStyle("-fx-border-color:green;-fx-pref-height: 8px; -fx-pref-width: 300px;");
        profile5.setStyle("-fx-border-color:green;-fx-pref-height: 8px; -fx-pref-width: 300px;");
        back.setStyle("-fx-background-color: transparent;-fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0");
        confirmBtn.setStyle("-fx-background-color: transparent;-fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0");
        editProfile.setStyle("-fx-background-color: transparent;-fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0");
        deleteProfile.setStyle("-fx-background-color: transparent;-fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;-fx-border-color:white;-fx-border-width: 3 3 3 3; -fx-background-insets: 0");
        label2.setStyle("-fx-text-fill: white; -fx-font-size: 10px; -fx-font-weight: bold;");

        /*
         * Creating the stackpane and adding all the attributes on top.
         */
        StackPane rootPane = new StackPane();
        BackgroundImage backgroundImage = new BackgroundImage(new Image("mainmenuwall.png"),
                BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        rootPane.setBackground(new Background(backgroundImage));

        rootPane.getChildren().add(newNameFld);
        newNameFld.setMaxWidth(200);

        StackPane.setMargin(newNameFld, new Insets(0, -620, 0, 0));
        rootPane.getChildren().add(gameTitle);
        StackPane.setMargin(gameTitle, new Insets(0, 0, 440, 0));
        rootPane.getChildren().add(errorLbl);
        StackPane.setMargin(errorLbl, new Insets(-50, -620, 0, 0));
        rootPane.getChildren().add(label3);
        StackPane.setMargin(label3, new Insets(-90, -620, 0, 0));
        rootPane.getChildren().add(profile1);
        StackPane.setMargin(profile1, new Insets(0, 20, 300, 0));
        rootPane.getChildren().add(profile2);
        StackPane.setMargin(profile2, new Insets(0, 20, 150, 0));
        rootPane.getChildren().add(profile3);
        StackPane.setMargin(profile3, new Insets(0, 20, 0, 0));
        rootPane.getChildren().add(profile4);
        StackPane.setMargin(profile4, new Insets(150, 20, 0, 0));
        rootPane.getChildren().add(profile5);
        StackPane.setMargin(profile5, new Insets(300, 20, 0, 0));
        rootPane.getChildren().add(back);
        StackPane.setMargin(back, new Insets(-440, 830, 0, 0));
        rootPane.getChildren().add(confirmBtn);
        StackPane.setMargin(confirmBtn, new Insets(100, 0, 0, 600));

        rootPane.getChildren().add(label2);
        StackPane.setMargin(label2, new Insets(-50, -620, 0, 0));
        errorLbl.setText("This User is Empty,Select used Profile");
        errorLbl.setVisible(false);
        newNameFld.setVisible(false);
        label3.setVisible(false);
        confirmBtn.setVisible(false);

        /**
         * Action for the back button to return to the existing profile page.
         */
        back.setOnAction(e -> {
            ExistingProfile existingProfile = new ExistingProfile();
            primaryStage.getScene().setRoot(existingProfile.getRootPane(primaryStage));
        });

        /**
         * Action for the confirm button to set the new username of the selected
         * profile.
         */
        confirmBtn.setOnAction((ActionEvent e) -> {
            if (!(usernameComparison(newNameFld.getText()))) {
                edit(currentName, primaryStage, newNameFld);
            } else {
                label2.setVisible(true);
                label2.setText("This Username is already in use,Pick Another");
            }
        });

        /**
         * Action for the profile1 button to append the contents of the button
         * when edits are made.
         */
        profile1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                if (!name1.equals("EMPTY")) {
                    newNameFld.clear();
                    label2.setVisible(false);
                    errorLbl.setVisible(false);
                    newNameFld.setVisible(true);
                    label3.setText("New UserName for Profile 1 :");
                    label3.setVisible(true);
                    currentName = name1;
                    currentLevel = currentLevel1;
                    currentCharacter = character1;
                    newNameFld.setEditable(true);
                    confirmBtn.setVisible(true);
                } else {
                    errorLbl.setVisible(true);
                    newNameFld.setEditable(false);
                    newNameFld.setVisible(false);
                    label3.setVisible(false);
                    confirmBtn.setVisible(false);

                }

            }
        });
        /**
         * Action for the profile2 button to append the contents of the button
         * when edits are made.
         */

        profile2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                if (!name2.equals("EMPTY")) {
                    newNameFld.clear();
                    label2.setVisible(false);
                    errorLbl.setVisible(false);
                    newNameFld.setVisible(true);
                    label3.setText("New UserName for Profile 2 :");
                    label3.setVisible(true);
                    currentName = name2;
                    currentLevel = currentLevel2;
                    currentCharacter = character2;
                    newNameFld.setEditable(true);
                    confirmBtn.setVisible(true);
                } else {
                    errorLbl.setVisible(true);
                    newNameFld.setEditable(false);
                    newNameFld.setVisible(false);
                    label3.setVisible(false);
                    confirmBtn.setVisible(false);

                }
            }
        });
        /**
         * Action for the profile3 button to append the contents of the button
         * when edits are made.
         */
        profile3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                if (!name3.equals("EMPTY")) {
                    newNameFld.clear();
                    label2.setVisible(false);
                    errorLbl.setVisible(false);
                    newNameFld.setVisible(true);
                    label3.setText("New UserName for Profile 3 :");
                    label3.setVisible(true);
                    currentName = name3;
                    currentLevel = currentLevel3;
                    currentCharacter = character3;
                    newNameFld.setEditable(true);
                    confirmBtn.setVisible(true);
                } else {
                    errorLbl.setVisible(true);
                    newNameFld.setEditable(false);
                    newNameFld.setVisible(false);
                    label3.setVisible(false);
                    confirmBtn.setVisible(false);
                }
            }
        });
        /**
         * Action for the profile4 button to append the contents of the button
         * when edits are made.
         */
        profile4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {

                if (!name4.equals("EMPTY")) {
                    label2.setVisible(false);
                    errorLbl.setVisible(false);
                    newNameFld.clear();
                    newNameFld.setVisible(true);
                    label3.setText("New UserName for Profile 4 :");
                    label3.setVisible(true);
                    currentName = name4;
                    currentLevel = currentLevel4;
                    currentCharacter = character4;
                    newNameFld.setEditable(true);
                    confirmBtn.setVisible(true);
                } else {
                    errorLbl.setVisible(true);

                    newNameFld.setEditable(false);
                    newNameFld.setVisible(false);
                    label3.setVisible(false);
                    confirmBtn.setVisible(false);
                }
            }
        });
        /**
         * Action for the profile5 button to append the contents of the button
         * when edits are made.
         */
        profile5.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {

                if (!name5.equals("EMPTY")) {
                    label2.setVisible(false);
                    errorLbl.setVisible(false);
                    newNameFld.clear();
                    newNameFld.setVisible(true);
                    label3.setText("New UserName for Profile 5 :");
                    label3.setVisible(true);
                    currentName = name5;
                    currentLevel = currentLevel5;
                    currentCharacter = character5;
                    newNameFld.setEditable(true);
                    confirmBtn.setVisible(true);
                } else {
                    errorLbl.setVisible(true);
                    newNameFld.setEditable(false);
                    newNameFld.setVisible(false);
                    label3.setVisible(false);
                    confirmBtn.setVisible(false);
                }

            }
        });

        Scene scene = new Scene(rootPane, 900, 500);
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    /**
     * File reader which reads in the contents of the player file.
     */

    public void fileReader() {
        File fileName = new File("Player.txt");
        Scanner in = null;

        String[] info;
        String readLine;
        try {

            // Now you have a String array containing each word in the current line
            in = new Scanner(fileName);

            if (in.hasNext()) {
                readLine = (in.nextLine());
                info = readLine.split(",");
                name1 = (info[0]);
                currentLevel1 = (info[1]);
                character1 = (info[2]);

            }
            if (in.hasNextLine()) {
                readLine = (in.nextLine());
                info = readLine.split(",");
                name2 = (info[0]);
                currentLevel2 = (info[1]);
                character2 = (info[2]);

            }
            if (in.hasNextLine()) {
                readLine = (in.nextLine());
                info = readLine.split(",");
                name3 = (info[0]);
                currentLevel3 = (info[1]);
                character3 = (info[2]);

            }
            if (in.hasNextLine()) {
                readLine = (in.nextLine());
                info = readLine.split(",");
                name4 = (info[0]);
                currentLevel4 = (info[1]);
                character4 = (info[2]);

            }
            if (in.hasNextLine()) {
                readLine = (in.nextLine());
                info = readLine.split(",");
                name5 = (info[0]);
                currentLevel5 = (info[1]);
                character5 = (info[2]);

            }

        } catch (FileNotFoundException e) {
            System.out.print("failed");
        }
    }

    /**
     * edit method edits the contents of the array .
     *
     * @param userLine - the user to be edited.
     * @param primaryStage - the main window.
     * @param newNameFld - the text box containing the new name.
     */

    public void edit(String userLine, Stage primaryStage, TextField newNameFld) {
        String[] info;
        String check;

        int count = 0;
        int username = 0;
        int existingUsers = 0;

        File fileName = new File(FILENAME);
        Scanner in = null;

        try {

            Scanner scan = new Scanner(fileName);
            ArrayList<String> data = new ArrayList<String>();
            while (scan.hasNextLine()) {
                String line[] = scan.next().split(",");
                data.add(line[0]);
                data.add(line[1]);
                data.add(line[2]);
                System.out.println("Contents of al: " + data);

            }
            for (int i = 0; i < data.size(); i++) {
                if (data.get(i).equals(currentName)) {
                    System.out.print(data.get(i));
                    data.set(i, newNameFld.getText());
                    System.out.print("edited");
                    System.out.println("Contents of al: " + data);
                    save(data);
                    EditProfile edit = new EditProfile();
                    primaryStage.getScene().setRoot(edit.getRootPane(primaryStage));

                }
            }

        } catch (FileNotFoundException e) {
            System.out.print("failed");
        }
    }

    /**
     * Method to save new name to file.
     *
     * @param data - array of all the data contents.
     */
    public void save(ArrayList<String> data) {
        try {
            FileWriter writer = new FileWriter("Player.txt");
            int size = data.size();
            System.out.println("Contents of al: " + data);
            System.out.print(data.size());
            for (int i = 0; i < size; i++) {
                if (i == (size - 1)) {
                    String str = data.get(i);
                    writer.write(str);
                } else if (i == 2 || i == 5 || i == 8 || i == 11 || i == 14) {
                    String str = data.get(i);
                    writer.write(str + "\n");
                } else {
                    String str = data.get(i);
                    writer.write(str + ",");

                }
            }

            writer.flush();
            writer.close();

        } catch (IOException ex) {
            System.out.print("failed it");
        }
    }

    /**
     * Method to check if the name entered has already been used.
     *
     * @param uName - The new name which is being entered.
     */
    public Boolean usernameComparison(String uName) {

        String check;
        boolean uFound = false;
        File fileName = new File(FILENAME);
        Scanner in = null;
        try {
            in = new Scanner(fileName);

            while (in.hasNext()) {
                String info[] = in.next().split(",");
                check = info[0];
                System.out.println(check);
                if (check.equalsIgnoreCase(uName)) {
                    uFound = true;
                }
            }

        } catch (FileNotFoundException e) {
            System.out.print("failed");
        }
        return uFound;
    }

    /**
     * Generates the start method.
     *
     * @param primaryStage - The main window.
     */

    public Pane getRootPane(Stage primaryStage) {
        start(primaryStage);
        return rootPane;

    }
}
