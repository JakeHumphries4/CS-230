import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class Sprite {
    private Image image;
    private double positionX;
    private double positionY;
    private double width;
    private double height;
    private String type;


    public Sprite(int posX, int posY, Image image, String type) {
        this.positionX = posX;
        this.positionY = posY;
        this.image = image;
        this.width = image.getWidth();
        this.height = image.getHeight();
        this.type = type;
    }

    public Sprite(int posX, int posY){
        this.positionX = posX;
        this.positionY = posY;
        this.type = type;
    }

    public void move(String dir, int dist) {
        if (dir.equals("north")) {
            this.positionY += dist;
        }
        if (dir.equals("south")) {
            this.positionY += -dist;
        }
        if (dir.equals("east")) {
            this.positionX += -dist;
        }
        if (dir.equals("west")) {
            this.positionX += dist;
        }
    }

    public void setImage(Image image) {
        this.image = image;
        this.width = image.getWidth();
        this.height = image.getHeight();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void addPositionX(double x) {
        this.positionX += x;
    }

    public void addPositionY(double y) {
        this.positionY += y;
    }

    public void setPositionX(double positionX) {
        this.positionX = positionX;
    }

    public void setPositionY(double positionY) {
        this.positionY = positionY;
    }

    public void render(GraphicsContext gc) {
        gc.drawImage(this.image, this.positionX, this.positionY);
    }

    public Rectangle2D getBoundary() {
        return new Rectangle2D(this.positionX, this.positionY, this.width, this.height);
    }

    public boolean intersects(Sprite s) {
        return s.getBoundary().intersects(this.getBoundary());
    }

    public double getPositionX() {
        return positionX;
    }

    public double getPositionY() {
        return positionY;
    }

    public String toString() {
        return " Position: [" + positionX + "," + positionY + "]\n SpriteType: "+type;
    }
}