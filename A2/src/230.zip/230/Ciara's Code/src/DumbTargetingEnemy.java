/**
 * An enemy that moves towards the player but doesn't go around obstacles.
 */
public class DumbTargetingEnemy extends Navigator {

    /**
     *Instantiates the dumb enemy with the cell it starts on.
     * @param cell The cell that the enemy starts on.
     */
    public DumbTargetingEnemy(Cell cell) {
        super(cell);
    }

    /**
     * Moves the dumb enemy towards the player without regard for obstacles in the way, although it is still blocked.
     * @param playerX The x-coordinate of the player.
     * @param playerY The y-coordinate of the player.
     * @return The direction the sprite should be shifted.
     */
    public String move(int playerX, int playerY) {
        String shiftDirection = null;
        if (getxCoord() > playerX && (Math.abs(getxCoord() - playerX) > Math.abs(getyCoord() - playerY)) && getCell().getWest().getCellType().equals("ground")) {
            moveWest();
            shiftDirection = "east";
        } else if (getxCoord() < playerX && (Math.abs(getxCoord() - playerX) > Math.abs(getyCoord() - playerY)) && getCell().getEast().getCellType().equals("ground")) {
            moveEast();
            shiftDirection = "west";
        } else if (getyCoord() > playerY && (Math.abs(getyCoord() - playerY) > Math.abs(getxCoord() - playerX)) && getCell().getNorth().getCellType().equals("ground")) {
            moveNorth();
            shiftDirection = "south";
        } else if (getyCoord() < playerY && (Math.abs(getyCoord() - playerY) > Math.abs(getxCoord() - playerX)) && getCell().getSouth().getCellType().equals("ground")) {
            moveSouth();
            shiftDirection = "north";
        }
        return shiftDirection;
    }
}
