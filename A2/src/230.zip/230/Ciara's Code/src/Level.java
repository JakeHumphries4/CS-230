import java.util.ArrayList;

public class Level {

    private ArrayList<Cell> cells;
    private ArrayList<Navigator> navigators;
    private int yDimensions;
    private int xDimensions;
    //Level number
    private int number;

    public Level() {
        cells = new ArrayList<>();
        navigators = new ArrayList<>();
    }

    public ArrayList<Cell> getCells()
    {
        return cells;
    }

    public void setCells(ArrayList<Cell> cells)
    {
        this.cells = cells;
    }

    public ArrayList<Navigator> getNavigators()
    {
        return navigators;
    }

    public void setNavigators(ArrayList<Navigator> navigators)
    {
        this.navigators = navigators;
    }

    public int getyDimensions()
    {
        return yDimensions;
    }

    public void setyDimensions(int yDimensions)
    {
        this.yDimensions = yDimensions;
    }

    public int getxDimensions()
    {
        return xDimensions;
    }

    public void setxDimensions(int xDimensions)
    {
        this.xDimensions = xDimensions;
    }

    public void addCell(Cell newCell)
    {
        cells.add(newCell);
    }

    public void addNavigator(Navigator newNavigator)
    {
        navigators.add(newNavigator);
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
