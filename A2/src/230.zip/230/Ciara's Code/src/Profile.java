
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ciara

 */
public class Profile {
    private String userName;
    private int currentLevel;
    private String character;
    public ArrayList<Boolean> continueLevelArray = new ArrayList<Boolean>();
    
    public Profile(String userName, String level, String character) {
        this.userName = userName;
        this.character = character;
        this.currentLevel = Integer.parseInt(level);
        for(int i =0;i<=6;i++){
            continueLevelArray.add(i,false);
        }
    }

    public String getUserName() {
        return userName;
    }

    public String getCharacter() {
        return character;
    }

    public Boolean getContinueLevelArray(int level) {
        Boolean continueState=false;
    
        for(int i =0;i<continueLevelArray.size();i++){
            if(i==level){
                continueState = continueLevelArray.get(i);
            }
        }
        return continueState;
    
    }

    public void setContinueLevelArray(int level,Boolean continueState) {
        for(int i =0;i<continueLevelArray.size();i++){
            if(i==level){
                continueLevelArray.set(i,continueState);
            }
        }
    }
   

    public void setCharacter(String character) {
        this.character = character;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getCurrentLevel() {
        return currentLevel;
    }
    
    public void setCurrentLevel(int currentLevel) {
        this.currentLevel = currentLevel;
    }
    
    public void saveState (Level levelInstance, Profile profileInstance){
        FileReader.Save(levelInstance,profileInstance);
        
    }

    
}
